from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, replace
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from evaluation.friedrich_semantic.action import (
    SemanticActionResult,
    SemanticActivityUnit,
    SimilarityProvider,
    evaluate_semantic_actions,
)
from evaluation.friedrich_semantic.flow import (
    SemanticFlowResult,
    _branch_relations,
    _loop_facts,
    _weak_components,
    evaluate_semantic_flow,
)
from evaluation.friedrich_semantic.structure import (
    SemanticStructureResult,
    _assign_hierarchy,
    _extract_graph_regions,
    evaluate_semantic_structure,
)
from evaluation.friedrich_v3.action import ACTION_SIMILARITY_THRESHOLD
from evaluation.friedrich_v3.core import EvalEdge, EvalGraph, EvalNode
from evaluation.friedrich_v3.flow import _precedence, _transitive_reduction

from .semantic_inventory import (
    SemanticInventory,
    SemanticOccurrence,
    SemanticUnit,
    load_inventory,
)


class InventoryAdapterError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class InventoryEligibility:
    active_unit_ids: tuple[str, ...]
    active_occurrence_ids: tuple[str, ...]
    primary_unit_ids: tuple[str, ...]
    primary_occurrence_ids: tuple[str, ...]
    text_only_unit_ids: tuple[str, ...]
    text_only_occurrence_ids: tuple[str, ...]
    retained_ambiguous_unit_ids: tuple[str, ...]
    retained_ambiguous_occurrence_ids: tuple[str, ...]
    ambiguous_action_unit_ids_excluded: tuple[str, ...]
    ambiguous_flow_occurrence_ids_excluded: tuple[str, ...]
    ambiguous_dependent_occurrence_ids_excluded: tuple[str, ...]
    rejected_proposal_count: int


@dataclass(frozen=True, slots=True)
class InventoryReferenceProjection:
    inventory: SemanticInventory
    eligibility: InventoryEligibility
    action_graph: EvalGraph
    flow_graph: EvalGraph
    action_units: tuple[SemanticActivityUnit, ...]
    flow_units: tuple[SemanticActivityUnit, ...]
    occurrence_node_ids: Mapping[str, tuple[str, ...]]
    diagnostics: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class InventoryEvaluationResult:
    eligibility: InventoryEligibility
    projection_diagnostics: Mapping[str, Any]
    action: SemanticActionResult
    flow: SemanticFlowResult
    structure: SemanticStructureResult


def load_reviewed_inventory_for_evaluation(
    path: str | Path,
    *,
    supported_case_ids: Sequence[str],
) -> SemanticInventory:
    source = Path(path)
    if source.name != "inventory_reviewed.json":
        raise InventoryAdapterError("evaluation requires inventory_reviewed.json")
    inventory = load_inventory(source)
    if inventory.case_id not in set(supported_case_ids):
        raise InventoryAdapterError(f"case is outside the supported cohort: {inventory.case_id}")
    if inventory.annotation_completion_state != "researcher_validated":
        raise InventoryAdapterError("inventory is not researcher validated")
    unfinished = [
        item.provenance.review_state
        for item in (*inventory.units, *inventory.occurrences)
        if item.provenance.review_state in {"draft", "needs_adjudication"}
    ]
    if unfinished:
        raise InventoryAdapterError(f"active inventory contains unfinished review states: {unfinished}")
    return inventory


def inventory_eligibility(
    inventory: SemanticInventory,
    *,
    retain_ambiguity_for_primary: bool = False,
) -> InventoryEligibility:
    ambiguous_unit_ids = frozenset(
        item.semantic_unit_id
        for item in inventory.units
        if item.provenance.review_state == "ambiguous"
    )
    ambiguous_occurrence_ids = frozenset(
        item.occurrence_id
        for item in inventory.occurrences
        if item.provenance.review_state == "ambiguous"
    )
    non_text_occurrences = tuple(
        item for item in inventory.occurrences if item.evidence_status != "text_only"
    )
    non_text_unit_ids = frozenset(
        item.semantic_unit_id for item in non_text_occurrences
    )
    if retain_ambiguity_for_primary:
        action_occurrences = non_text_occurrences
        primary_occurrences = non_text_occurrences
    else:
        action_occurrences = tuple(
            item for item in non_text_occurrences
            if item.semantic_unit_id not in ambiguous_unit_ids
        )
        primary_occurrences = tuple(
            item for item in action_occurrences
            if item.occurrence_id not in ambiguous_occurrence_ids
        )
    primary_unit_ids = frozenset(item.semantic_unit_id for item in action_occurrences)
    text_only_occurrences = tuple(
        item for item in inventory.occurrences if item.evidence_status == "text_only"
    )
    ambiguity_excluded_occurrences = tuple(
        item for item in non_text_occurrences if item not in primary_occurrences
    )
    return InventoryEligibility(
        tuple(item.semantic_unit_id for item in inventory.units),
        tuple(item.occurrence_id for item in inventory.occurrences),
        tuple(item.semantic_unit_id for item in inventory.units if item.semantic_unit_id in primary_unit_ids),
        tuple(item.occurrence_id for item in primary_occurrences),
        tuple(
            item.semantic_unit_id for item in inventory.units
            if item.semantic_unit_id not in non_text_unit_ids
        ),
        tuple(item.occurrence_id for item in text_only_occurrences),
        tuple(item.semantic_unit_id for item in inventory.units if item.semantic_unit_id in ambiguous_unit_ids),
        tuple(item.occurrence_id for item in inventory.occurrences if item.occurrence_id in ambiguous_occurrence_ids),
        tuple(
            item.semantic_unit_id for item in inventory.units
            if item.semantic_unit_id in ambiguous_unit_ids
            and item.semantic_unit_id in non_text_unit_ids
            and item.semantic_unit_id not in primary_unit_ids
        ),
        tuple(item.occurrence_id for item in ambiguity_excluded_occurrences),
        tuple(
            item.occurrence_id for item in ambiguity_excluded_occurrences
            if item.semantic_unit_id in ambiguous_unit_ids
            and item.occurrence_id not in ambiguous_occurrence_ids
        ),
        len(inventory.rejected_proposals),
    )


def _node_type(node: Mapping[str, Any], outgoing: int, *, control_supported: bool) -> str:
    kind = str(node.get("node_type") or "")
    if kind == "StartEvent":
        return "initial"
    if kind == "StopEvent":
        return "final"
    if kind == "Gateway":
        if outgoing > 1 and control_supported:
            return "fork" if node.get("gateway_type") == "Parallel" else "decision"
        return "join" if node.get("gateway_type") == "Parallel" else "merge"
    if kind in {"Task", "SubProcess"}:
        return "action"
    return "merge"


def _modality(occurrences: Sequence[SemanticOccurrence]) -> str:
    if len(occurrences) > 1 or any(item.recurrence_role != "none" for item in occurrences):
        return "repeated"
    if any(item.necessity == "optional" for item in occurrences):
        return "optional"
    if any(item.necessity == "conditional" or item.branch_scope_ids for item in occurrences):
        return "branch_specific"
    return "mandatory"


def _passage(occurrences: Sequence[SemanticOccurrence]) -> str:
    seen: set[str] = set()
    excerpts: list[str] = []
    for occurrence in occurrences:
        for evidence in occurrence.source_text_evidence:
            if evidence.exact_excerpt not in seen:
                seen.add(evidence.exact_excerpt)
                excerpts.append(evidence.exact_excerpt)
    return " | ".join(excerpts)


def _branch_parts(scope_id: str) -> tuple[str, str] | None:
    parts = scope_id.split(":", 2)
    return (parts[1], parts[2]) if len(parts) == 3 and parts[0] == "branch" else None


def _primary_anchors(
    occurrence: SemanticOccurrence,
    nodes: Mapping[str, Mapping[str, Any]],
) -> tuple[tuple[str, str, str | None], ...]:
    referenced = [nodes[item] for item in occurrence.reference_node_ids if item in nodes]
    for kinds in (
        {"Task"},
        {"IntermediateEvent"},
    ):
        selected = [item for item in referenced if item.get("node_type") in kinds]
        if selected:
            return tuple(("node", str(item["node_id"]), None) for item in selected)
    for scope_id in occurrence.branch_scope_ids:
        parts = _branch_parts(scope_id)
        if parts and parts[0] in occurrence.reference_node_ids:
            return (("edge", parts[0], parts[1]),)
    selected = [
        item for item in referenced
        if item.get("node_type") in {"StartEvent", "StopEvent", "SubProcess", "Gateway"}
    ]
    if selected:
        return tuple(("node", str(item["node_id"]), None) for item in selected[:1])
    raise InventoryAdapterError(
        f"eligible occurrence has no process anchor: {occurrence.occurrence_id}"
    )


def _nearest_action_edges(graph: EvalGraph, node_to_unit: Mapping[str, str]) -> set[tuple[str, str]]:
    result: set[tuple[str, str]] = set()
    for start, source_unit in node_to_unit.items():
        queue = deque(graph.outgoing[start])
        seen: set[str] = set()
        while queue:
            current = queue.popleft()
            if current in seen:
                continue
            seen.add(current)
            if current in node_to_unit:
                target_unit = node_to_unit[current]
                if source_unit != target_unit:
                    result.add((source_unit, target_unit))
                continue
            queue.extend(graph.outgoing[current])
    return result


def project_reviewed_inventory(
    inventory: SemanticInventory,
    reference_evidence: Mapping[str, Any],
    *,
    _retain_ambiguity_for_primary: bool = False,
) -> InventoryReferenceProjection:
    eligibility = inventory_eligibility(
        inventory,
        retain_ambiguity_for_primary=_retain_ambiguity_for_primary,
    )
    primary_unit_ids = set(eligibility.primary_unit_ids)
    primary_occurrence_ids = set(eligibility.primary_occurrence_ids)
    units = {item.semantic_unit_id: item for item in inventory.units if item.semantic_unit_id in primary_unit_ids}
    action_occurrences = tuple(
        item for item in inventory.occurrences
        if item.evidence_status != "text_only"
        and item.semantic_unit_id in primary_unit_ids
    )
    occurrences = tuple(
        item for item in inventory.occurrences if item.occurrence_id in primary_occurrence_ids
    )
    occurrences_by_unit = {
        unit_id: tuple(item for item in action_occurrences if item.semantic_unit_id == unit_id)
        for unit_id in primary_unit_ids
    }

    raw_nodes = {str(item["node_id"]): item for item in reference_evidence.get("nodes", [])}
    sequence_edges = tuple(
        item for item in reference_evidence.get("edges", [])
        if item.get("edge_type") == "SequenceFlow"
        and str(item.get("source_id")) in raw_nodes
        and str(item.get("target_id")) in raw_nodes
    )
    outgoing_count: dict[str, int] = {}
    for edge in sequence_edges:
        source = str(edge["source_id"])
        outgoing_count[source] = outgoing_count.get(source, 0) + 1

    node_anchors: dict[str, set[str]] = {}
    occurrence_anchors: dict[str, tuple[tuple[str, str, str | None], ...]] = {}
    for occurrence in action_occurrences:
        anchors = _primary_anchors(occurrence, raw_nodes)
        occurrence_anchors[occurrence.occurrence_id] = anchors
        for kind, left, right in anchors:
            if kind == "node":
                node_anchors.setdefault(left, set()).add(occurrence.semantic_unit_id)

    used_branch_ids = {
        scope_id for occurrence in occurrences for scope_id in occurrence.branch_scope_ids
    }
    supported_control_ids = {
        str(scope["gateway_id"])
        for scope in reference_evidence.get("branch_scopes", [])
        if scope.get("scope_id") in used_branch_ids
    }
    supported_control_ids.update(
        reference_id
        for occurrence in occurrences
        for boundary in occurrence.boundary_constraints
        if boundary.boundary_type in {"exclusive", "parallel", "loop", "recurrence"}
        for reference_id in boundary.reference_element_ids
    )

    clone_for: dict[tuple[str, str, str | None, str], str] = {}
    clone_occurrences: dict[str, set[str]] = {}
    for occurrence in action_occurrences:
        for kind, left, right in occurrence_anchors[occurrence.occurrence_id]:
            key = (kind, left, right, occurrence.semantic_unit_id)
            clone = clone_for.setdefault(
                key,
                f"inventory:{kind}:{left}:{right or '-'}:{occurrence.semantic_unit_id}",
            )
            clone_occurrences.setdefault(clone, set()).add(occurrence.occurrence_id)

    replacement_ids = {
        node_id for node_id in node_anchors
        if raw_nodes[node_id].get("node_type") not in {"StartEvent", "StopEvent"}
    }
    before_final = {
        node_id for node_id in node_anchors if raw_nodes[node_id].get("node_type") == "StopEvent"
    }
    after_initial = {
        node_id for node_id in node_anchors if raw_nodes[node_id].get("node_type") == "StartEvent"
    }

    graph_nodes: list[EvalNode] = []
    process_ids = {
        str(edge[side]) for edge in sequence_edges for side in ("source_id", "target_id")
    }
    for node_id in sorted(process_ids):
        if node_id in replacement_ids:
            continue
        raw = raw_nodes[node_id]
        kind = _node_type(
            raw,
            outgoing_count.get(node_id, 0),
            control_supported=node_id in supported_control_ids,
        )
        if kind == "action" and node_id not in node_anchors:
            kind = "merge"
        graph_nodes.append(EvalNode(node_id, kind, raw.get("label") or None))
    for (kind, left, right, unit_id), clone in sorted(clone_for.items()):
        flow_active = bool(clone_occurrences[clone] & primary_occurrence_ids)
        graph_nodes.append(EvalNode(
            clone,
            "action" if flow_active else "merge",
            units[unit_id].canonical_meaning if flow_active else None,
        ))

    def node_clones(node_id: str) -> tuple[str, ...]:
        return tuple(sorted(
            clone for (kind, left, _right, _unit), clone in clone_for.items()
            if kind == "node" and left == node_id
        ))

    def edge_clones(source: str, target: str) -> tuple[str, ...]:
        return tuple(sorted(
            clone for (kind, left, right, _unit), clone in clone_for.items()
            if kind == "edge" and left == source and right == target
        ))

    graph_edges: set[tuple[str, str, str | None]] = set()
    for edge in sequence_edges:
        source, target = str(edge["source_id"]), str(edge["target_id"])
        source_nodes = node_clones(source) if source in replacement_ids else (source,)
        target_nodes = node_clones(target) if target in replacement_ids else (target,)
        if source in after_initial:
            source_nodes = node_clones(source)
        if target in before_final:
            target_nodes = node_clones(target)
        inserted = edge_clones(source, target)
        label = edge.get("label") or None
        if inserted:
            graph_edges.update((left, middle, label) for left in source_nodes for middle in inserted)
            graph_edges.update((middle, right, None) for middle in inserted for right in target_nodes)
        else:
            graph_edges.update((left, right, label) for left in source_nodes for right in target_nodes)
    for node_id in before_final:
        graph_edges.update((clone, node_id, None) for clone in node_clones(node_id))
    for node_id in after_initial:
        graph_edges.update((node_id, clone, None) for clone in node_clones(node_id))

    clones_by_original: dict[str, set[str]] = {}
    for (kind, left, right, _unit), clone in clone_for.items():
        if kind == "node":
            clones_by_original.setdefault(left, set()).add(clone)
        else:
            clones_by_original.setdefault(left, set()).add(clone)
            if right:
                clones_by_original.setdefault(right, set()).add(clone)
    occurrence_nodes = {
        occurrence.occurrence_id: tuple(sorted(
            clone_for[(kind, left, right, occurrence.semantic_unit_id)]
            for kind, left, right in occurrence_anchors[occurrence.occurrence_id]
        ))
        for occurrence in occurrences
    }
    for occurrence in occurrences:
        current = occurrence_nodes[occurrence.occurrence_id]
        for boundary in occurrence.boundary_constraints:
            ids = list(boundary.reference_element_ids)
            if boundary.boundary_type not in {"actor_handoff", "observable_order"}:
                continue
            if len(ids) >= 2:
                left = clones_by_original.get(ids[0], set())
                right = clones_by_original.get(ids[-1], set())
                graph_edges.update((a, b, None) for a in left for b in right if a != b)
            elif ids:
                related = clones_by_original.get(ids[0], set())
                if boundary.side == "after":
                    graph_edges.update((a, b, None) for a in related for b in current if a != b)
                elif boundary.side == "before":
                    graph_edges.update((a, b, None) for a in current for b in related if a != b)

    flow_graph = EvalGraph(
        tuple(graph_nodes),
        tuple(EvalEdge(source, target, label) for source, target, label in sorted(graph_edges)),
    )
    clone_to_unit = {
        clone: unit_id for (_kind, _left, _right, unit_id), clone in clone_for.items()
    }
    flow_unit_ids = {
        item.semantic_unit_id for item in occurrences
    }
    unit_flow_nodes = {
        unit_id: tuple(sorted(
            node for node, owner in clone_to_unit.items()
            if owner == unit_id and clone_occurrences[node] & primary_occurrence_ids
        ))
        for unit_id in flow_unit_ids
    }

    action_edges = _nearest_action_edges(flow_graph, clone_to_unit)
    action_edges = {
        (left, right) for left, right in action_edges
        if left in primary_unit_ids and right in primary_unit_ids
    }
    # Bidirectional Action-only links permit frozen many-to-one grouping without
    # asserting precedence between meanings co-located in one reference node.
    for anchored_units in node_anchors.values():
        action_edges.update(
            (left, right)
            for left in anchored_units
            for right in anchored_units
            if left != right and left in primary_unit_ids and right in primary_unit_ids
        )
    action_graph = EvalGraph(
        tuple(EvalNode(unit_id, "action", units[unit_id].canonical_meaning) for unit_id in sorted(units)),
        tuple(EvalEdge(source, target) for source, target in sorted(action_edges)),
    )

    action_units = tuple(
        SemanticActivityUnit(
            unit_id,
            unit.canonical_meaning,
            (unit_id,),
            (unit.canonical_meaning,),
            "core",
            _modality(occurrences_by_unit[unit_id]),
            unit.actor,
            _passage(occurrences_by_unit[unit_id]),
            0,
            1.0,
            1.0,
        )
        for unit_id, unit in sorted(units.items())
    )
    flow_units = tuple(
        replace(
            unit,
            reference_ids=unit_flow_nodes[unit.unit_id],
            reference_labels=tuple(unit.meaning for _ in unit_flow_nodes[unit.unit_id]),
        )
        for unit in action_units if unit.unit_id in flow_unit_ids
    )
    if any(not item.reference_ids for item in flow_units):
        raise InventoryAdapterError("a primary unit has no flow projection")

    diagnostics = {
        "active_unit_count": len(inventory.units),
        "active_occurrence_count": len(inventory.occurrences),
        "primary_unit_count": len(primary_unit_ids),
        "primary_occurrence_count": len(primary_occurrence_ids),
        "text_only_unit_ids": list(eligibility.text_only_unit_ids),
        "text_only_occurrence_ids": list(eligibility.text_only_occurrence_ids),
        "retained_ambiguous_inventory_item_count": (
            len(eligibility.retained_ambiguous_unit_ids)
            + len(eligibility.retained_ambiguous_occurrence_ids)
        ),
        "ambiguous_action_unit_ids_excluded": list(
            eligibility.ambiguous_action_unit_ids_excluded
        ),
        "ambiguous_flow_occurrence_ids_excluded": list(
            eligibility.ambiguous_flow_occurrence_ids_excluded
        ),
        "ambiguous_dependent_occurrence_ids_excluded": list(
            eligibility.ambiguous_dependent_occurrence_ids_excluded
        ),
        "ambiguous_control_fact_count_excluded": sum(
            len(item.branch_scope_ids)
            + len(item.loop_scope_ids)
            + (item.recurrence_role != "none")
            + len(item.boundary_constraints)
            for item in inventory.occurrences
            if item.occurrence_id in set(
                eligibility.ambiguous_flow_occurrence_ids_excluded
            )
        ),
        "rejected_proposal_count": len(inventory.rejected_proposals),
        "projected_occurrence_node_count": len(clone_for),
        "branch_scoped_occurrence_count": sum(bool(item.branch_scope_ids) for item in occurrences),
        "loop_scoped_occurrence_count": sum(bool(item.loop_scope_ids) for item in occurrences),
        "recurrence_occurrence_count": sum(item.recurrence_role != "none" for item in occurrences),
        "boundary_fact_count": sum(len(item.boundary_constraints) for item in occurrences),
        "supported_control_reference_ids": sorted(supported_control_ids),
        "suppressed_unreviewed_split_ids": sorted(
            node_id for node_id, raw in raw_nodes.items()
            if raw.get("node_type") == "Gateway"
            and outgoing_count.get(node_id, 0) > 1
            and node_id not in supported_control_ids
        ),
        "shared_reference_nodes": {
            node_id: sorted(unit_ids) for node_id, unit_ids in node_anchors.items()
            if len(unit_ids) > 1
        },
        "occurrence_nodes": {key: list(value) for key, value in occurrence_nodes.items()},
    }
    return InventoryReferenceProjection(
        inventory,
        eligibility,
        action_graph,
        flow_graph,
        action_units,
        flow_units,
        occurrence_nodes,
        diagnostics,
    )


def _reference_flow_relation_signatures(
    graph: EvalGraph,
    units: Sequence[SemanticActivityUnit],
) -> set[tuple[str, str, str, str]]:
    """Return the frozen Flow reference universe without evaluating a candidate."""
    reference_to_unit = {
        reference_id: unit.unit_id
        for unit in units
        for reference_id in unit.reference_ids
    }
    unit_ids = {unit.unit_id for unit in units}
    strict_nodes = _precedence(graph, set(reference_to_unit))
    full_precedence = {
        (reference_to_unit[left], reference_to_unit[right])
        for left, right in strict_nodes
        if reference_to_unit[left] != reference_to_unit[right]
    }
    loops = _loop_facts(graph, reference_to_unit)
    full_precedence.update(loops.within_iteration)
    reduced = _transitive_reduction(set(full_precedence))
    branch_relations, same_branch = _branch_relations(graph, reference_to_unit)
    branch_relations = {
        pair: relation_type
        for pair, relation_type in branch_relations.items()
        if pair not in full_precedence
        and (pair[1], pair[0]) not in full_precedence
    }
    components = _weak_components(graph, reference_to_unit)
    result = {
        (
            "required_precedence",
            source,
            target,
            "loop_local"
            if (source, target) in loops.within_iteration
            else "branch_local"
            if (source, target) in same_branch
            else "global",
        )
        for source, target in reduced
    }
    result.update(
        ("required_precedence", source, target, "loop_recurrence")
        for source, target in loops.recurrence
    )
    result.update(
        (relation_type, source, target, "branch_local")
        for (source, target), relation_type in branch_relations.items()
    )
    for index, source in enumerate(sorted(unit_ids)):
        for target in sorted(unit_ids)[index + 1:]:
            pair = (source, target)
            if (
                (source, target) not in full_precedence
                and (target, source) not in full_precedence
                and pair not in branch_relations
                and components.get(source) == components.get(target)
            ):
                result.add(("unordered", source, target, "global"))
    return result


def _reference_region_signatures(
    graph: EvalGraph,
    units: Sequence[SemanticActivityUnit],
    source_text: str,
) -> set[tuple[Any, ...]]:
    reference_units = {
        reference_id: frozenset({unit.unit_id})
        for unit in units
        for reference_id in unit.reference_ids
    }
    regions = _assign_hierarchy(
        _extract_graph_regions(graph, reference_units, "reference", source_text)
    )
    return {
        (
            item.region_id,
            item.region_type,
            item.entry_unit_ids,
            item.branch_unit_ids,
            item.continuation_unit_ids,
            item.body_unit_ids,
            item.exit_unit_ids,
            item.restart_target_unit_ids,
        )
        for item in regions
    }


def evaluate_inventory_candidate(
    case_id: str,
    candidate_id: str,
    inventory: SemanticInventory,
    reference_evidence: Mapping[str, Any],
    generated: EvalGraph,
    similarity: SimilarityProvider,
    *,
    source_text: str,
    threshold: float = ACTION_SIMILARITY_THRESHOLD,
) -> InventoryEvaluationResult:
    if inventory.case_id != case_id:
        raise InventoryAdapterError("inventory case identity mismatch")
    projection = project_reviewed_inventory(inventory, reference_evidence)
    retained_ambiguity_count = (
        len(projection.eligibility.retained_ambiguous_unit_ids)
        + len(projection.eligibility.retained_ambiguous_occurrence_ids)
    )
    ambiguity_inclusive = (
        project_reviewed_inventory(
            inventory,
            reference_evidence,
            _retain_ambiguity_for_primary=True,
        )
        if retained_ambiguity_count
        else projection
    )
    primary_relations = _reference_flow_relation_signatures(
        projection.flow_graph, projection.flow_units
    )
    ambiguity_inclusive_relations = _reference_flow_relation_signatures(
        ambiguity_inclusive.flow_graph, ambiguity_inclusive.flow_units
    )
    primary_regions = _reference_region_signatures(
        projection.flow_graph, projection.flow_units, source_text
    )
    ambiguity_inclusive_regions = _reference_region_signatures(
        ambiguity_inclusive.flow_graph,
        ambiguity_inclusive.flow_units,
        source_text,
    )
    projection_diagnostics = {
        **projection.diagnostics,
        "ambiguous_flow_relation_count_excluded": len(
            ambiguity_inclusive_relations - primary_relations
        ),
        "ambiguous_flow_relation_denominator_delta": (
            len(ambiguity_inclusive_relations) - len(primary_relations)
        ),
        "ambiguous_control_flow_region_count_excluded": len(
            ambiguity_inclusive_regions - primary_regions
        ),
        "ambiguous_control_flow_region_denominator_delta": (
            len(ambiguity_inclusive_regions) - len(primary_regions)
        ),
    }
    action = evaluate_semantic_actions(
        case_id,
        candidate_id,
        projection.action_graph,
        generated,
        similarity,
        threshold,
        source_text=source_text,
        semantic_activity_units=projection.action_units,
    )
    action = replace(action, semantic_activity_units=projection.flow_units)
    flow = evaluate_semantic_flow(
        case_id,
        candidate_id,
        projection.flow_graph,
        generated,
        action,
        source_text=source_text,
    )
    structure = evaluate_semantic_structure(
        case_id,
        candidate_id,
        projection.flow_graph,
        generated,
        action,
        flow,
        source_text=source_text,
    )
    return InventoryEvaluationResult(
        projection.eligibility,
        projection_diagnostics,
        action,
        flow,
        structure,
    )


def load_reference_evidence(path: str | Path) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise InventoryAdapterError("reference evidence must be a JSON object")
    return value


def result_summary(result: InventoryEvaluationResult) -> dict[str, Any]:
    return {
        "eligibility": asdict(result.eligibility),
        "projection": dict(result.projection_diagnostics),
        "retained_ambiguity": {
            "inventory_items": result.projection_diagnostics[
                "retained_ambiguous_inventory_item_count"
            ],
            "action_units_excluded": len(
                result.eligibility.ambiguous_action_unit_ids_excluded
            ),
            "flow_occurrences_excluded": len(
                result.eligibility.ambiguous_flow_occurrence_ids_excluded
            ),
            "flow_relations_excluded": result.projection_diagnostics[
                "ambiguous_flow_relation_count_excluded"
            ],
            "control_facts_excluded": result.projection_diagnostics[
                "ambiguous_control_fact_count_excluded"
            ],
            "control_regions_excluded": result.projection_diagnostics[
                "ambiguous_control_flow_region_count_excluded"
            ],
        },
        "action": {
            "reference_units": len(result.action.semantic_activity_units),
            "generated_actions": len(result.action.generated_activity_groups),
            "matches": len(result.action.accepted_mappings),
            "anchor_matches": len(result.action.anchor_matches),
            **result.action.counts.to_dict(),
        },
        "flow": {
            "matched_action_basis": len(result.flow.semantic_group_anchors),
            "reference_relations": result.flow.total_required_relations,
            "generated_relations": len(result.flow.generated_precedence_constraints),
            "evaluable_relations": result.flow.comparable_required_relations,
            "preserved_relations": len(result.flow.preserved_constraints),
            "violated_relations": len(result.flow.missing_constraints),
            "coverage": result.flow.precedence_coverage,
            **result.flow.counts.to_dict(),
        },
        "structure": {
            "eligible_regions": result.structure.total_required_regions,
            "evaluable_regions": result.structure.comparable_regions,
            "supported_regions": result.structure.full_count,
            "partial_regions": result.structure.partial_count,
            "violated_regions": result.structure.fail_count,
            "unscorable_regions": result.structure.unscorable_count,
            "unsupported_generated_regions": len(result.structure.unsupported_generated_regions),
            "score": result.structure.full_rate,
            "coverage": result.structure.structure_coverage,
        },
    }
