from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Literal, Mapping, Sequence


INVENTORY_SCHEMA_VERSION = "friedrich-semantic-inventory/v1"
METHODOLOGY_VERSION = "friedrich-semantic-inventory-methodology/v1"

Direction = Literal[
    "internal", "inbound", "outbound", "bidirectional", "none", "unknown"
]
Polarity = Literal["positive", "negative"]
Necessity = Literal["mandatory", "conditional", "optional"]
RecurrenceRole = Literal["none", "initial", "loop_body", "repeated", "loop_exit"]
EvidenceStatus = Literal["text_and_reference", "text_only", "reference_only", "conflict"]
BoundaryType = Literal[
    "exclusive", "parallel", "loop", "recurrence", "actor_handoff", "observable_order"
]
BoundarySide = Literal["before", "after", "internal"]
ReviewState = Literal[
    "draft", "accepted", "modified", "rejected", "ambiguous", "needs_adjudication"
]
CompletionState = Literal["draft", "researcher_validated", "frozen"]

DIRECTIONS = frozenset(("internal", "inbound", "outbound", "bidirectional", "none", "unknown"))
POLARITIES = frozenset(("positive", "negative"))
NECESSITIES = frozenset(("mandatory", "conditional", "optional"))
RECURRENCE_ROLES = frozenset(("none", "initial", "loop_body", "repeated", "loop_exit"))
EVIDENCE_STATUSES = frozenset(("text_and_reference", "text_only", "reference_only", "conflict"))
BOUNDARY_TYPES = frozenset((
    "exclusive", "parallel", "loop", "recurrence", "actor_handoff", "observable_order"
))
BOUNDARY_SIDES = frozenset(("before", "after", "internal"))
REVIEW_STATES = frozenset((
    "draft", "accepted", "modified", "rejected", "ambiguous", "needs_adjudication"
))
TERMINAL_REVIEW_STATES = frozenset(("accepted", "modified", "rejected"))
COMPLETION_STATES = frozenset(("draft", "researcher_validated", "frozen"))
HEX_256 = re.compile(r"^[0-9a-f]{64}$")
UNIT_SPLIT_DIMENSIONS = frozenset((
    "operation", "business_object", "actor", "responsibility", "source_participant",
    "recipient_participant", "direction", "polarity", "behavior_changing_modality",
    "branch_boundary", "loop_boundary", "observable_order",
))
OCCURRENCE_DISTINCTION_DIMENSIONS = frozenset((
    "process_position", "branch", "before_after_rework", "trigger", "deadline",
    "loop_role", "actor_handoff", "behavioral_obligation",
))


class InventoryValidationError(ValueError):
    """Raised when an inventory violates the frozen methodology contract."""


def _required_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InventoryValidationError(f"{field} must be a non-empty string")
    return value.strip()


def _nullable_text(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _required_text(value, field)


def _enum(value: Any, allowed: frozenset[str], field: str) -> str:
    if value not in allowed:
        raise InventoryValidationError(f"{field} must be one of {sorted(allowed)}")
    return str(value)


def _string_tuple(value: Any, field: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise InventoryValidationError(f"{field} must be a list of non-empty strings")
    result = tuple(item.strip() for item in value)
    if len(result) != len(set(result)):
        raise InventoryValidationError(f"{field} must not contain duplicates")
    return result


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical_json_hash(value: Mapping[str, Any]) -> str:
    payload = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return sha256_bytes(payload.encode("utf-8"))


def requires_unit_split(semantic_differences: Sequence[str]) -> bool:
    """Apply the frozen meaning-level split rule without consulting candidates."""
    return bool(set(semantic_differences) & UNIT_SPLIT_DIMENSIONS)


def requires_distinct_occurrence(context_differences: Sequence[str]) -> bool:
    """Keep repeated meaning distinct when its behavioral context differs."""
    return bool(set(context_differences) & OCCURRENCE_DISTINCTION_DIMENSIONS)


def activity_evidence_disposition(
    node_type: str, *, compound_action_control: bool = False
) -> Literal["activity_evidence", "control_only", "human_review_required"]:
    normalized = node_type.strip().casefold()
    if normalized in {"action", "activity", "task"}:
        return "activity_evidence"
    if normalized in {"decision", "gateway", "control", "fork", "join", "merge"}:
        return "human_review_required" if compound_action_control else "control_only"
    return "human_review_required"


def _iso_timestamp(value: Any, field: str) -> str:
    text = _required_text(value, field)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise InventoryValidationError(f"{field} must be an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        raise InventoryValidationError(f"{field} must include a timezone")
    return text


@dataclass(frozen=True, slots=True)
class MaterialIdentity:
    path: str
    sha256: str

    @classmethod
    def from_dict(cls, value: Mapping[str, Any], field: str) -> "MaterialIdentity":
        _exact_keys(value, {"path", "sha256"}, field)
        path = _required_text(value.get("path"), f"{field}.path")
        digest = _required_text(value.get("sha256"), f"{field}.sha256")
        if not HEX_256.fullmatch(digest):
            raise InventoryValidationError(f"{field}.sha256 must be a lowercase SHA-256")
        _reject_generated_path(path, f"{field}.path")
        return cls(path, digest)


@dataclass(frozen=True, slots=True)
class SourceTextEvidence:
    document_hash: str
    start_offset: int
    end_offset: int
    exact_excerpt: str

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SourceTextEvidence":
        _exact_keys(
            value, {"document_hash", "start_offset", "end_offset", "exact_excerpt"},
            "SourceTextEvidence",
        )
        digest = _required_text(value.get("document_hash"), "document_hash")
        if not HEX_256.fullmatch(digest):
            raise InventoryValidationError("document_hash must be a lowercase SHA-256")
        start, end = value.get("start_offset"), value.get("end_offset")
        if not isinstance(start, int) or isinstance(start, bool) or start < 0:
            raise InventoryValidationError("start_offset must be a non-negative integer")
        if not isinstance(end, int) or isinstance(end, bool) or end <= start:
            raise InventoryValidationError("end_offset must be greater than start_offset")
        return cls(digest, start, end, _required_text(value.get("exact_excerpt"), "exact_excerpt"))

    def validate_against(self, source_text: str, document_hash: str) -> None:
        if self.document_hash != document_hash:
            raise InventoryValidationError("source evidence document hash differs from process text")
        if self.end_offset > len(source_text):
            raise InventoryValidationError("source evidence offsets exceed process text length")
        if source_text[self.start_offset:self.end_offset] != self.exact_excerpt:
            raise InventoryValidationError("source evidence excerpt does not match exact offsets")


@dataclass(frozen=True, slots=True)
class BoundaryConstraint:
    boundary_type: BoundaryType
    side: BoundarySide
    reference_element_ids: tuple[str, ...]

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "BoundaryConstraint":
        _exact_keys(value, {"boundary_type", "side", "reference_element_ids"}, "BoundaryConstraint")
        ids = _string_tuple(value.get("reference_element_ids"), "reference_element_ids")
        if not ids:
            raise InventoryValidationError("boundary constraint requires reference element IDs")
        return cls(
            _enum(value.get("boundary_type"), BOUNDARY_TYPES, "boundary_type"),  # type: ignore[arg-type]
            _enum(value.get("side"), BOUNDARY_SIDES, "side"),  # type: ignore[arg-type]
            ids,
        )


@dataclass(frozen=True, slots=True)
class ReviewProvenance:
    draft_method: Literal["deterministic", "human", "llm_assisted"]
    original_proposal: Mapping[str, Any]
    researcher_edits: Mapping[str, Any]
    review_state: ReviewState
    rationale: str | None
    timestamp: str

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReviewProvenance":
        _exact_keys(value, {
            "draft_method", "original_proposal", "researcher_edits", "review_state",
            "rationale", "timestamp",
        }, "ReviewProvenance")
        method = _enum(
            value.get("draft_method"), frozenset(("deterministic", "human", "llm_assisted")),
            "draft_method",
        )
        original, edits = value.get("original_proposal"), value.get("researcher_edits")
        if not isinstance(original, Mapping) or not isinstance(edits, Mapping):
            raise InventoryValidationError("proposal and researcher edits must be objects")
        state = _enum(value.get("review_state"), REVIEW_STATES, "review_state")
        rationale = _nullable_text(value.get("rationale"), "rationale")
        if state in {"modified", "rejected", "ambiguous", "needs_adjudication"} and not rationale:
            raise InventoryValidationError(f"{state} review requires a rationale")
        if state == "accepted" and edits:
            raise InventoryValidationError("accepted means the original proposal was not edited")
        if state == "modified" and not edits:
            raise InventoryValidationError("modified review requires researcher edits")
        return cls(
            method, dict(original), dict(edits), state, rationale,
            _iso_timestamp(value.get("timestamp"), "timestamp"),  # type: ignore[arg-type]
        )


@dataclass(frozen=True, slots=True)
class SemanticUnit:
    semantic_unit_id: str
    canonical_meaning: str
    operation: str
    business_object: str | None
    actor: str | None
    source_participant: str | None
    recipient_participant: str | None
    direction: Direction
    polarity: Polarity
    purpose: str | None
    provenance: ReviewProvenance

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SemanticUnit":
        _exact_keys(value, {
            "semantic_unit_id", "canonical_meaning", "operation", "business_object",
            "actor", "source_participant", "recipient_participant", "direction",
            "polarity", "purpose", "provenance",
        }, "SemanticUnit")
        return cls(
            _required_text(value.get("semantic_unit_id"), "semantic_unit_id"),
            _required_text(value.get("canonical_meaning"), "canonical_meaning"),
            _required_text(value.get("operation"), "operation"),
            _nullable_text(value.get("business_object"), "business_object"),
            _nullable_text(value.get("actor"), "actor"),
            _nullable_text(value.get("source_participant"), "source_participant"),
            _nullable_text(value.get("recipient_participant"), "recipient_participant"),
            _enum(value.get("direction"), DIRECTIONS, "direction"),  # type: ignore[arg-type]
            _enum(value.get("polarity"), POLARITIES, "polarity"),  # type: ignore[arg-type]
            _nullable_text(value.get("purpose"), "purpose"),
            ReviewProvenance.from_dict(_mapping(value.get("provenance"), "provenance")),
        )


@dataclass(frozen=True, slots=True)
class SemanticOccurrence:
    occurrence_id: str
    semantic_unit_id: str
    occurrence_index: int
    necessity: Necessity
    branch_scope_ids: tuple[str, ...]
    loop_scope_ids: tuple[str, ...]
    recurrence_role: RecurrenceRole
    source_text_evidence: tuple[SourceTextEvidence, ...]
    reference_node_ids: tuple[str, ...]
    evidence_status: EvidenceStatus
    boundary_constraints: tuple[BoundaryConstraint, ...]
    provenance: ReviewProvenance

    @property
    def automatically_eligible(self) -> bool:
        return (
            self.evidence_status == "text_and_reference"
            and self.provenance.review_state in {"accepted", "modified"}
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SemanticOccurrence":
        _exact_keys(value, {
            "occurrence_id", "semantic_unit_id", "occurrence_index", "necessity",
            "branch_scope_ids", "loop_scope_ids", "recurrence_role", "source_text_evidence",
            "reference_node_ids", "evidence_status", "boundary_constraints", "provenance",
        }, "SemanticOccurrence")
        index = value.get("occurrence_index")
        if not isinstance(index, int) or isinstance(index, bool) or index < 1:
            raise InventoryValidationError("occurrence_index must be a positive integer")
        evidence_raw, boundaries_raw = value.get("source_text_evidence"), value.get("boundary_constraints")
        if not isinstance(evidence_raw, list) or not isinstance(boundaries_raw, list):
            raise InventoryValidationError("evidence and boundary constraints must be lists")
        evidence = tuple(SourceTextEvidence.from_dict(item) for item in evidence_raw)
        status = _enum(value.get("evidence_status"), EVIDENCE_STATUSES, "evidence_status")
        references = _string_tuple(value.get("reference_node_ids"), "reference_node_ids")
        if status in {"text_and_reference", "text_only", "conflict"} and not evidence:
            raise InventoryValidationError(f"{status} occurrence requires source-text evidence")
        if status in {"text_and_reference", "reference_only", "conflict"} and not references:
            raise InventoryValidationError(f"{status} occurrence requires reference-node evidence")
        return cls(
            _required_text(value.get("occurrence_id"), "occurrence_id"),
            _required_text(value.get("semantic_unit_id"), "semantic_unit_id"),
            index,
            _enum(value.get("necessity"), NECESSITIES, "necessity"),  # type: ignore[arg-type]
            _string_tuple(value.get("branch_scope_ids"), "branch_scope_ids"),
            _string_tuple(value.get("loop_scope_ids"), "loop_scope_ids"),
            _enum(value.get("recurrence_role"), RECURRENCE_ROLES, "recurrence_role"),  # type: ignore[arg-type]
            evidence,
            references,
            status,  # type: ignore[arg-type]
            tuple(BoundaryConstraint.from_dict(item) for item in boundaries_raw),
            ReviewProvenance.from_dict(_mapping(value.get("provenance"), "provenance")),
        )


@dataclass(frozen=True, slots=True)
class FreezeRecord:
    inventory_hash: str
    freeze_timestamp: str
    unresolved_ambiguity_count: int
    annotation_completion_state: Literal["frozen"] = "frozen"

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FreezeRecord":
        _exact_keys(value, {
            "inventory_hash", "freeze_timestamp", "unresolved_ambiguity_count",
            "annotation_completion_state",
        }, "FreezeRecord")
        digest = _required_text(value.get("inventory_hash"), "inventory_hash")
        if not HEX_256.fullmatch(digest):
            raise InventoryValidationError("inventory_hash must be a lowercase SHA-256")
        count = value.get("unresolved_ambiguity_count")
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise InventoryValidationError("unresolved_ambiguity_count must be non-negative")
        if value.get("annotation_completion_state") != "frozen":
            raise InventoryValidationError("freeze record completion state must be frozen")
        return cls(digest, _iso_timestamp(value.get("freeze_timestamp"), "freeze_timestamp"), count)


@dataclass(frozen=True, slots=True)
class SemanticInventory:
    schema_version: str
    methodology_version: str
    inventory_id: str
    inventory_version: str
    case_id: str
    process_text: MaterialIdentity
    reference_model: MaterialIdentity
    annotation_completion_state: CompletionState
    units: tuple[SemanticUnit, ...]
    occurrences: tuple[SemanticOccurrence, ...]
    rejected_proposals: tuple[ReviewProvenance, ...]
    supersedes: str | None
    revision_reason: str | None
    freeze_record: FreezeRecord | None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SemanticInventory":
        _exact_keys(value, {
            "schema_version", "methodology_version", "inventory_id", "inventory_version",
            "case_id", "process_text", "reference_model", "annotation_completion_state",
            "units", "occurrences", "rejected_proposals", "supersedes", "revision_reason",
            "freeze_record",
        }, "SemanticInventory")
        if value.get("schema_version") != INVENTORY_SCHEMA_VERSION:
            raise InventoryValidationError("unsupported inventory schema version")
        if value.get("methodology_version") != METHODOLOGY_VERSION:
            raise InventoryValidationError("unsupported methodology version")
        units_raw, occurrences_raw, rejected_raw = (
            value.get("units"), value.get("occurrences"), value.get("rejected_proposals")
        )
        if not all(isinstance(item, list) for item in (units_raw, occurrences_raw, rejected_raw)):
            raise InventoryValidationError("units, occurrences, and rejected proposals must be lists")
        freeze_raw = value.get("freeze_record")
        inventory = cls(
            INVENTORY_SCHEMA_VERSION,
            METHODOLOGY_VERSION,
            _required_text(value.get("inventory_id"), "inventory_id"),
            _required_text(value.get("inventory_version"), "inventory_version"),
            _required_text(value.get("case_id"), "case_id"),
            MaterialIdentity.from_dict(_mapping(value.get("process_text"), "process_text"), "process_text"),
            MaterialIdentity.from_dict(_mapping(value.get("reference_model"), "reference_model"), "reference_model"),
            _enum(value.get("annotation_completion_state"), COMPLETION_STATES, "annotation_completion_state"),  # type: ignore[arg-type]
            tuple(SemanticUnit.from_dict(item) for item in units_raw),
            tuple(SemanticOccurrence.from_dict(item) for item in occurrences_raw),
            tuple(ReviewProvenance.from_dict(item) for item in rejected_raw),
            _nullable_text(value.get("supersedes"), "supersedes"),
            _nullable_text(value.get("revision_reason"), "revision_reason"),
            FreezeRecord.from_dict(_mapping(freeze_raw, "freeze_record")) if freeze_raw is not None else None,
        )
        validate_inventory(inventory)
        return inventory

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def is_frozen(self) -> bool:
        return self.annotation_completion_state == "frozen"

    @property
    def automatically_eligible_occurrences(self) -> tuple[SemanticOccurrence, ...]:
        return tuple(item for item in self.occurrences if item.automatically_eligible)


def _mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise InventoryValidationError(f"{field} must be an object")
    return value


def _exact_keys(value: Mapping[str, Any], expected: set[str], field: str) -> None:
    actual = set(value)
    if actual != expected:
        raise InventoryValidationError(
            f"{field} fields differ; missing={sorted(expected-actual)}, extra={sorted(actual-expected)}"
        )


def _reject_generated_path(path: str, field: str) -> None:
    parts = {part.casefold() for part in Path(path).parts}
    banned = {"candidates", "candidate", "cohorts", "results", "human_review"}
    if parts & banned or any(part.startswith("candidate_") for part in parts):
        raise InventoryValidationError(f"{field} points to prohibited generated/evaluation material")


def validate_inventory(
    inventory: SemanticInventory,
    *,
    process_text_bytes: bytes | None = None,
    reference_bytes: bytes | None = None,
) -> None:
    unit_ids = [item.semantic_unit_id for item in inventory.units]
    occurrence_ids = [item.occurrence_id for item in inventory.occurrences]
    if len(unit_ids) != len(set(unit_ids)) or len(occurrence_ids) != len(set(occurrence_ids)):
        raise InventoryValidationError("unit and occurrence IDs must be unique")
    known = set(unit_ids)
    if any(item.semantic_unit_id not in known for item in inventory.occurrences):
        raise InventoryValidationError("every occurrence must reference an inventory unit")
    indices: dict[str, list[int]] = {}
    for occurrence in inventory.occurrences:
        indices.setdefault(occurrence.semantic_unit_id, []).append(occurrence.occurrence_index)
    if any(sorted(values) != list(range(1, len(values) + 1)) for values in indices.values()):
        raise InventoryValidationError("occurrence indices must be contiguous per semantic unit")
    if any(unit_id not in indices for unit_id in unit_ids):
        raise InventoryValidationError("every accepted semantic unit requires an occurrence")
    reviewed_items = [item.provenance for item in (*inventory.units, *inventory.occurrences)]
    if any(
        item.provenance.review_state in {"accepted", "modified"}
        and item.evidence_status != "reference_only"
        and not item.source_text_evidence
        for item in inventory.occurrences
    ):
        raise InventoryValidationError(
            "accepted/modified non-reference-only occurrences require exact process-text evidence"
        )
    unfinished = sum(
        item.review_state in {"draft", "needs_adjudication"}
        for item in reviewed_items
    )
    retained_ambiguity = sum(item.review_state == "ambiguous" for item in reviewed_items)
    if inventory.annotation_completion_state == "researcher_validated":
        if unfinished:
            raise InventoryValidationError(
                "researcher-validated inventory cannot contain draft or needs-adjudication items"
            )
        if any(
            item.review_state not in {"accepted", "modified", "ambiguous"}
            for item in reviewed_items
        ):
            raise InventoryValidationError(
                "researcher-validated inventory may contain only accepted, modified, or ambiguous items"
            )
    if inventory.annotation_completion_state == "frozen":
        if unfinished or retained_ambiguity:
            raise InventoryValidationError("frozen inventory cannot contain unresolved review states")
        if any(item.review_state not in {"accepted", "modified"} for item in reviewed_items):
            raise InventoryValidationError("frozen inventory may contain only accepted/modified items")
    if inventory.annotation_completion_state == "frozen" and inventory.freeze_record is None:
        raise InventoryValidationError("frozen inventory requires a freeze record")
    if inventory.annotation_completion_state != "frozen" and inventory.freeze_record is not None:
        raise InventoryValidationError("only frozen inventory may contain a freeze record")
    if inventory.supersedes and not inventory.revision_reason:
        raise InventoryValidationError("a version that supersedes another requires a revision reason")
    if process_text_bytes is not None:
        digest = sha256_bytes(process_text_bytes)
        if digest != inventory.process_text.sha256:
            raise InventoryValidationError("process text hash differs from inventory")
        try:
            source_text = process_text_bytes.decode("utf-8")
        except UnicodeDecodeError:
            source_text = process_text_bytes.decode("windows-1252")
        for occurrence in inventory.occurrences:
            for evidence in occurrence.source_text_evidence:
                evidence.validate_against(source_text, digest)
    if reference_bytes is not None and sha256_bytes(reference_bytes) != inventory.reference_model.sha256:
        raise InventoryValidationError("reference model hash differs from inventory")
    if inventory.freeze_record:
        if inventory.freeze_record.unresolved_ambiguity_count != unfinished + retained_ambiguity:
            raise InventoryValidationError("freeze ambiguity count differs from inventory")
        if inventory.freeze_record.inventory_hash != inventory_content_hash(inventory):
            raise InventoryValidationError("frozen inventory hash is invalid")


def inventory_content_hash(inventory: SemanticInventory) -> str:
    value = inventory.to_dict()
    value["annotation_completion_state"] = "researcher_validated"
    value["freeze_record"] = None
    return canonical_json_hash(value)


def freeze_inventory(
    inventory: SemanticInventory,
    *,
    process_text_bytes: bytes,
    reference_bytes: bytes,
    freeze_timestamp: str,
) -> SemanticInventory:
    if inventory.is_frozen:
        raise InventoryValidationError("frozen inventory is immutable")
    if inventory.annotation_completion_state != "researcher_validated":
        raise InventoryValidationError("inventory must be researcher-validated before freezing")
    validate_inventory(
        inventory, process_text_bytes=process_text_bytes, reference_bytes=reference_bytes
    )
    timestamp = _iso_timestamp(freeze_timestamp, "freeze_timestamp")
    record = FreezeRecord(inventory_content_hash(inventory), timestamp, 0)
    frozen = replace(inventory, annotation_completion_state="frozen", freeze_record=record)
    validate_inventory(frozen, process_text_bytes=process_text_bytes, reference_bytes=reference_bytes)
    return frozen


def start_new_version(
    inventory: SemanticInventory,
    *,
    inventory_version: str,
    revision_reason: str,
    revision_timestamp: str,
) -> SemanticInventory:
    if not inventory.is_frozen:
        raise InventoryValidationError("only a frozen inventory can be versioned")
    version = _required_text(inventory_version, "inventory_version")
    if version == inventory.inventory_version:
        raise InventoryValidationError("new inventory version must differ from frozen version")
    reason = _required_text(revision_reason, "revision_reason")
    timestamp = _iso_timestamp(revision_timestamp, "revision_timestamp")

    def reopen(item: SemanticUnit | SemanticOccurrence) -> SemanticUnit | SemanticOccurrence:
        value = asdict(item)
        original = {key: item_value for key, item_value in value.items() if key != "provenance"}
        provenance = ReviewProvenance(
            "human", original, {}, "draft", f"Reopened for {version}: {reason}", timestamp
        )
        return replace(item, provenance=provenance)

    return replace(
        inventory,
        inventory_version=version,
        annotation_completion_state="draft",
        units=tuple(reopen(item) for item in inventory.units),  # type: ignore[misc]
        occurrences=tuple(reopen(item) for item in inventory.occurrences),  # type: ignore[misc]
        supersedes=f"{inventory.inventory_id}@{inventory.inventory_version}",
        revision_reason=reason,
        freeze_record=None,
    )


def load_inventory(path: str | Path) -> SemanticInventory:
    source = Path(path)
    return SemanticInventory.from_dict(json.loads(source.read_text(encoding="utf-8")))


def write_inventory(path: str | Path, inventory: SemanticInventory) -> None:
    target = Path(path)
    if target.exists():
        raise FileExistsError(f"Refusing to overwrite inventory: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(inventory.to_dict(), indent=2, ensure_ascii=True, sort_keys=True) + "\n",
        encoding="utf-8",
    )
