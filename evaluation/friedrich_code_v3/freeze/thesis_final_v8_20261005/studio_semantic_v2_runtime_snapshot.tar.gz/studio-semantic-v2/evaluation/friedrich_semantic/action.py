from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import re
from typing import Any, Literal, Mapping, Sequence

from evaluation.friedrich_v3.action import (
    ACTION_SIMILARITY_THRESHOLD,
    ActionMatch,
    SimilarityProvider,
    _adjacent,
    _compound,
    _compatibility_taxonomy,
    compatibility_veto,
    evaluate_actions as evaluate_legacy_actions,
)
from evaluation.friedrich_v3.core import (
    AutomaticItem,
    Counts,
    EvalGraph,
    evaluation_item_id,
    normalize_label,
    reachable,
)


SOURCE_GROUNDING_THRESHOLD = 0.38
CONTEXTUAL_RESCUE_FLOOR = 0.32

Importance = Literal["core", "secondary"]
Modality = Literal["mandatory", "optional", "branch_specific", "repeated"]
MappingKind = Literal["one_to_one", "many_to_one", "one_to_many", "contextual_paraphrase"]

_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is",
    "it", "of", "on", "or", "that", "the", "then", "this", "to", "was", "were",
    "with", "within", "after", "before", "customer", "process", "service",
}
_GENERIC_OPERATIONS = {"do", "execute", "handle", "manage", "perform", "process"}
_GENERIC_OBJECTS = {"activity", "application", "case", "item", "process", "request", "task", "work"}
_ESSENTIAL_ROLES = {
    "approver", "board", "manager", "management", "billing", "accounting", "police",
    "supplier", "vendor", "customer", "claimant", "assessor",
}
_OPTIONAL_CUES = (" may ", " might ", " optionally ", " if necessary ", " sometimes ")
_BRANCH_CUES = (" if ", " either ", " otherwise ", " in case ", " whether ")
_REPEAT_CUES = (" again", " repeat", " until ", " another ", " and so on")
_DETAIL_CUES = ("for example", "e.g.", "can be achieved", "sometimes")


@dataclass(frozen=True, slots=True)
class SemanticActivityUnit:
    unit_id: str
    meaning: str
    reference_ids: tuple[str, ...]
    reference_labels: tuple[str, ...]
    importance: Importance
    modality: Modality
    actor: str | None
    source_passage: str
    source_passage_index: int
    source_grounding: float
    lexical_grounding: float


@dataclass(frozen=True, slots=True)
class GeneratedActivityGroup:
    group_id: str
    generated_ids: tuple[str, ...]
    generated_labels: tuple[str, ...]
    source_supported: bool
    source_passage: str
    source_grounding: float
    lexical_grounding: float
    explicit_actor: str | None


@dataclass(frozen=True, slots=True)
class SemanticMapping:
    mapping_id: str
    unit_ids: tuple[str, ...]
    generated_group_id: str
    reference_ids: tuple[str, ...]
    generated_ids: tuple[str, ...]
    kind: MappingKind
    similarities: tuple[float, ...]
    confidence: float
    evidence: Mapping[str, Any]
    review_triggers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class GranularityVariation:
    variation_id: str
    kind: Literal["merge", "split"]
    unit_ids: tuple[str, ...]
    generated_ids: tuple[str, ...]
    rationale: str


@dataclass(frozen=True, slots=True)
class SemanticActionResult:
    case_id: str
    candidate_id: str
    semantic_activity_units: tuple[SemanticActivityUnit, ...]
    generated_activity_groups: tuple[GeneratedActivityGroup, ...]
    accepted_mappings: tuple[SemanticMapping, ...]
    missing_core_activities: tuple[str, ...]
    unsupported_generated_activities: tuple[str, ...]
    granularity_variations: tuple[GranularityVariation, ...]
    ambiguous_mappings: tuple[Mapping[str, Any], ...]
    optional_detail_mismatches: tuple[Mapping[str, Any], ...]
    review_flags: tuple[str, ...]
    counts: Counts
    items: tuple[AutomaticItem, ...]
    anchor_matches: tuple[ActionMatch, ...]

    @property
    def metric_defined(self) -> bool:
        return bool(self.counts.tp or self.counts.fp or self.counts.fn)

    @property
    def matches(self) -> tuple[ActionMatch, ...]:
        """One-to-one compatibility anchors; semantic mappings remain many-to-many."""
        return self.anchor_matches

    @property
    def reference_to_generated(self) -> dict[str, str]:
        return {match.reference_id: match.generated_id for match in self.anchor_matches}

    @property
    def generated_to_reference(self) -> dict[str, str]:
        return {match.generated_id: match.reference_id for match in self.anchor_matches}

    @property
    def occurrence_ambiguous_reference_ids(self) -> frozenset[str]:
        return frozenset(match.reference_id for match in self.anchor_matches if match.occurrence_ambiguous)

    @property
    def contested_reference_ids(self) -> frozenset[str]:
        return frozenset(match.reference_id for match in self.anchor_matches if match.contested)

    @property
    def review_pending_reference_ids(self) -> frozenset[str]:
        return frozenset(match.reference_id for match in self.anchor_matches if match.review_pending)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _passages(source_text: str) -> tuple[str, ...]:
    cleaned = re.sub(r"https?://\S+", " ", source_text.replace("\ufffd", " "))
    # Friedrich texts contain presentation line wrapping that is not a semantic
    # boundary. Sentence punctuation is the stable passage boundary.
    cleaned = re.sub(r"[\r\n]+", " ", cleaned)
    parts = re.split(r"(?<=[.!?])(?:\s+|(?=[A-Z]))", cleaned)
    return tuple(part.strip() for part in parts if len((normalize_label(part) or "").split()) >= 3)


def _tokens(value: str | None) -> set[str]:
    def stem(token: str) -> str:
        if token.endswith("ies") and len(token) > 4:
            return token[:-3] + "y"
        if token.endswith("es") and len(token) > 4:
            return token[:-2]
        if token.endswith("s") and len(token) > 3:
            return token[:-1]
        return token

    return {
        stem(token) for token in (normalize_label(value) or "").split()
        if len(token) > 2 and token not in _STOPWORDS
    }


def _lexical_grounding(label: str | None, passage: str) -> float:
    label_tokens = _tokens(label)
    if not label_tokens:
        return 0.0
    passage_tokens = _tokens(passage)
    return len(label_tokens & passage_tokens) / len(label_tokens)


def _best_source_evidence(
    labels: Sequence[str], passages: Sequence[str], similarity: SimilarityProvider
) -> tuple[list[int], list[float], list[float]]:
    if not labels:
        return [], [], []
    if not passages:
        return [-1] * len(labels), [0.0] * len(labels), [0.0] * len(labels)
    scores = similarity.matrix(labels, passages)
    if len(scores) != len(labels) or any(len(row) != len(passages) for row in scores):
        raise ValueError("Similarity provider returned an invalid source-grounding matrix")
    indices, semantic, lexical = [], [], []
    for label, row in zip(labels, scores):
        lexical_row = [_lexical_grounding(label, passage) for passage in passages]
        index = max(
            range(len(passages)),
            key=lambda item: (row[item] + 0.15 * lexical_row[item], row[item], -item),
        )
        indices.append(index)
        semantic.append(float(row[index]))
        lexical.append(lexical_row[index])
    return indices, semantic, lexical


def _modality(passage: str) -> Modality:
    normalized = f" {normalize_label(passage) or ''} "
    if any(cue in normalized for cue in _REPEAT_CUES):
        return "repeated"
    if any(cue in normalized for cue in _OPTIONAL_CUES):
        return "optional"
    if any(cue in normalized for cue in _BRANCH_CUES):
        return "branch_specific"
    return "mandatory"


def _actor(label: str | None, passage: str) -> str | None:
    words = set((normalize_label(label) or "").split()) | set(
        (normalize_label(passage) or "").split()
    )
    present = sorted(_ESSENTIAL_ROLES & words)
    return " ".join(present) if present else None


def _explicit_actor(label: str | None) -> str | None:
    present = sorted(_ESSENTIAL_ROLES & set((normalize_label(label) or "").split()))
    return " ".join(present) if present else None


def _compound_component_compatible(reference_label: str, generated_label: str) -> bool:
    if compatibility_veto(reference_label, generated_label).compatible:
        return True
    if not _compound(reference_label):
        return False
    operations = set(_compatibility_taxonomy()["operation_families"])
    reference_operations = operations & set(reference_label.split())
    generated_operations = operations & set(generated_label.split())
    return bool(reference_operations & generated_operations)


def _is_generic(label: str | None) -> bool:
    raw_tokens = set((normalize_label(label) or "").split())
    if not raw_tokens:
        return True
    operations = raw_tokens & _GENERIC_OPERATIONS
    specific = raw_tokens - _STOPWORDS - _GENERIC_OPERATIONS - _GENERIC_OBJECTS
    return bool(operations) and len(specific) < 2


def _is_grounded(semantic: float, lexical: float) -> bool:
    return semantic >= SOURCE_GROUNDING_THRESHOLD or lexical >= 0.5


def _generated_source_supported(semantic: float, lexical: float) -> bool:
    # Generated wording is not used to create a TP. A modestly broader support
    # test only prevents source-consistent paraphrases from becoming false FP.
    return semantic >= 0.34 or lexical >= 0.4


def _is_secondary(passage: str, semantic: float, lexical: float) -> bool:
    normalized = normalize_label(passage) or ""
    return not _is_grounded(semantic, lexical) or any(cue in normalized for cue in _DETAIL_CUES)


def _mapping(
    case_id: str,
    candidate_id: str,
    units: Sequence[SemanticActivityUnit],
    generated_ids: Sequence[str],
    generated_group_id: str,
    kind: MappingKind,
    similarities: Sequence[float],
    evidence: Mapping[str, Any],
    review_triggers: Sequence[str] = (),
) -> SemanticMapping:
    unit_ids = tuple(unit.unit_id for unit in units)
    return SemanticMapping(
        evaluation_item_id(case_id, candidate_id, "semantic-action", kind, *unit_ids, *generated_ids),
        unit_ids,
        generated_group_id,
        tuple(reference_id for unit in units for reference_id in unit.reference_ids),
        tuple(generated_ids),
        kind,
        tuple(float(score) for score in similarities),
        min(similarities) if similarities else 0.0,
        dict(evidence),
        tuple(sorted(set(review_triggers))),
    )


def evaluate_semantic_actions(
    case_id: str,
    candidate_id: str,
    reference: EvalGraph,
    generated: EvalGraph,
    similarity: SimilarityProvider,
    threshold: float = ACTION_SIMILARITY_THRESHOLD,
    *,
    source_text: str,
    reference_review_evidence: Sequence[Mapping[str, Any]] = (),
    semantic_activity_units: Sequence[SemanticActivityUnit] | None = None,
) -> SemanticActionResult:
    """Evaluate source-grounded business activity preservation.

    Reference actions nominate deterministic unit candidates. The process text
    decides whether each candidate is core and whether unmatched generated
    behavior is supported. The legacy assignment is retained only for stable
    one-to-one anchors and as evidence for semantic grouping.
    """
    if not source_text.strip():
        raise ValueError("Source process text is required for semantic Action evaluation")
    if not 0.0 <= threshold <= 1.0:
        raise ValueError("Action threshold must be between 0 and 1")

    ref = sorted((node for node in reference.nodes if node.type == "action"), key=lambda node: node.id)
    gen = sorted((node for node in generated.nodes if node.type == "action"), key=lambda node: node.id)
    passages = _passages(source_text)
    ref_labels = [node.label or "" for node in ref]
    gen_labels = [node.label or "" for node in gen]
    ref_source_index, ref_source_score, ref_lexical = _best_source_evidence(
        ref_labels, passages, similarity
    )
    gen_source_index, gen_source_score, gen_lexical = _best_source_evidence(
        gen_labels, passages, similarity
    )
    pair_scores = similarity.matrix(ref_labels, gen_labels)
    if len(pair_scores) != len(ref) or any(len(row) != len(gen) for row in pair_scores):
        raise ValueError("Similarity provider returned an invalid action matrix")

    if semantic_activity_units is None:
        units = tuple(
            SemanticActivityUnit(
                f"unit:{node.id}",
                node.label or "",
                (node.id,),
                (node.label or "",),
                "secondary" if (
                    not _tokens(node.label)
                    or _is_secondary(
                        passages[ref_source_index[index]] if ref_source_index[index] >= 0 else "",
                        ref_source_score[index], ref_lexical[index],
                    )
                ) else "core",
                _modality(passages[ref_source_index[index]]) if ref_source_index[index] >= 0 else "mandatory",
                _actor(node.label, passages[ref_source_index[index]]) if ref_source_index[index] >= 0 else None,
                passages[ref_source_index[index]] if ref_source_index[index] >= 0 else "",
                ref_source_index[index],
                ref_source_score[index],
                ref_lexical[index],
            )
            for index, node in enumerate(ref)
        )
    else:
        supplied = tuple(semantic_activity_units)
        supplied_by_reference = {
            unit.reference_ids[0]: unit
            for unit in supplied
            if len(unit.reference_ids) == 1
        }
        if len(supplied_by_reference) != len(supplied) or set(supplied_by_reference) != {
            node.id for node in ref
        }:
            raise ValueError(
                "Supplied semantic activity units must map one-to-one to reference action nodes"
            )
        units = tuple(supplied_by_reference[node.id] for node in ref)
    unit_by_ref = {unit.reference_ids[0]: unit for unit in units}
    generated_groups = tuple(
        GeneratedActivityGroup(
            f"group:{node.id}", (node.id,), (node.label or "",),
            _generated_source_supported(gen_source_score[index], gen_lexical[index]),
            passages[gen_source_index[index]] if gen_source_index[index] >= 0 else "",
            gen_source_score[index], gen_lexical[index], _explicit_actor(node.label),
        )
        for index, node in enumerate(gen)
    )
    group_by_gen = {group.generated_ids[0]: group for group in generated_groups}

    legacy = evaluate_legacy_actions(
        case_id, candidate_id, reference, generated, similarity, threshold,
        source_text=source_text, reference_review_evidence=reference_review_evidence,
    )
    ref_index = {node.id: index for index, node in enumerate(ref)}
    gen_index = {node.id: index for index, node in enumerate(gen)}
    mappings: list[SemanticMapping] = []
    mapped_ref: set[str] = set()
    mapped_gen: set[str] = set()
    for match in legacy.matches:
        unit = unit_by_ref[match.reference_id]
        group = group_by_gen[match.generated_id]
        mappings.append(_mapping(
            case_id, candidate_id, [unit], [match.generated_id], group.group_id,
            "one_to_one", [match.similarity],
            {
                "basis": "deterministic_legacy_anchor",
                "source_passage": unit.source_passage,
                "source_grounded": unit.importance == "core",
            },
            [reason for reason in match.uncertainty_reasons
             if reason not in {"possible_merge_action", "possible_split_action"}],
        ))
        mapped_ref.add(match.reference_id)
        mapped_gen.add(match.generated_id)

    # A strict one-to-one assignment can attach an earlier generated occurrence
    # to the later of two identical reference occurrences when the later action
    # is bundled into a compound node. Repair only fully ordered, exact-label
    # occurrences for which that compound node supplies the displaced meaning.
    for missing in ref:
        if missing.id in mapped_ref:
            continue
        for mapping_index, existing in enumerate(tuple(mappings)):
            if len(existing.reference_ids) != 1 or len(existing.generated_ids) != 1:
                continue
            occupied_ref = reference.by_id[existing.reference_ids[0]]
            if normalize_label(missing.label) != normalize_label(occupied_ref.label):
                continue
            occupied_gen_id = existing.generated_ids[0]
            missing_before = occupied_ref.id in reachable(reference, missing.id)
            missing_after = missing.id in reachable(reference, occupied_ref.id)
            compound_candidates = [
                other for other in mappings
                if len(other.generated_ids) == 1
                and _compound(generated.by_id[other.generated_ids[0]].label)
                and pair_scores[ref_index[occupied_ref.id]][gen_index[other.generated_ids[0]]] >= threshold
                and _adjacent(reference, occupied_ref.id, other.reference_ids[0])
            ]
            ordered = [
                other for other in compound_candidates
                if (
                    missing_before
                    and other.generated_ids[0] in reachable(generated, occupied_gen_id)
                ) or (
                    missing_after
                    and occupied_gen_id in reachable(generated, other.generated_ids[0])
                )
            ]
            if len(ordered) != 1:
                continue
            missing_unit = unit_by_ref[missing.id]
            score = pair_scores[ref_index[missing.id]][gen_index[occupied_gen_id]]
            mappings[mapping_index] = _mapping(
                case_id, candidate_id, [missing_unit], [occupied_gen_id],
                existing.generated_group_id, "one_to_one", [score],
                {"basis": "ordered_duplicate_occurrence_reassignment",
                 "displaced_reference_id": occupied_ref.id},
            )
            mapped_ref.remove(occupied_ref.id)
            mapped_ref.add(missing.id)
            break

    # Context can rescue a non-generic paraphrase when both labels point to the
    # same source passage. This remains reviewable and never overrides a veto.
    rescue_candidates: list[tuple[float, str, str]] = []
    for i, ref_node in enumerate(ref):
        if ref_node.id in mapped_ref or units[i].importance != "core":
            continue
        for j, gen_node in enumerate(gen):
            if gen_node.id in mapped_gen or _is_generic(gen_node.label):
                continue
            same_passage = ref_source_index[i] >= 0 and ref_source_index[i] == gen_source_index[j]
            compatible = compatibility_veto(ref_node.label or "", gen_node.label or "").compatible
            if same_passage and compatible and pair_scores[i][j] >= CONTEXTUAL_RESCUE_FLOOR:
                rescue_candidates.append((pair_scores[i][j], ref_node.id, gen_node.id))
    for score, reference_id, generated_id in sorted(rescue_candidates, reverse=True):
        if reference_id in mapped_ref or generated_id in mapped_gen:
            continue
        unit, group = unit_by_ref[reference_id], group_by_gen[generated_id]
        mappings.append(_mapping(
            case_id, candidate_id, [unit], [generated_id], group.group_id,
            "contextual_paraphrase", [score],
            {"basis": "shared_source_passage", "source_passage": unit.source_passage},
            ["low_confidence_contextual_paraphrase"],
        ))
        mapped_ref.add(reference_id)
        mapped_gen.add(generated_id)

    # Safe merge: an explicit compound generated label may preserve an adjacent
    # reference activity without consuming another generated action.
    for i, ref_node in enumerate(ref):
        if ref_node.id in mapped_ref or units[i].importance != "core":
            continue
        choices: list[tuple[float, str, str]] = []
        for mapping in mappings:
            if len(mapping.generated_ids) != 1:
                continue
            generated_id = mapping.generated_ids[0]
            j = gen_index[generated_id]
            if (
                _compound(gen[j].label)
                and not _is_generic(gen[j].label)
                and pair_scores[i][j] >= threshold
                and compatibility_veto(ref_node.label or "", gen[j].label or "").compatible
                and any(_adjacent(reference, ref_node.id, mapped_id) for mapped_id in mapping.reference_ids)
            ):
                choices.append((pair_scores[i][j], generated_id, mapping.mapping_id))
        if not choices:
            continue
        score, generated_id, prior_mapping_id = max(choices)
        prior_index = next(index for index, item in enumerate(mappings) if item.mapping_id == prior_mapping_id)
        prior = mappings[prior_index]
        combined_units = [unit_by_ref[item] for item in prior.reference_ids] + [units[i]]
        mappings[prior_index] = _mapping(
            case_id, candidate_id, combined_units, [generated_id], prior.generated_group_id,
            "many_to_one", [*prior.similarities, score],
            {"basis": "explicit_compound_label_and_adjacent_reference_context",
             "generated_label": gen[gen_index[generated_id]].label},
        )
        mapped_ref.add(ref_node.id)

    # Safe split: adjacent generated actions can jointly preserve an explicitly
    # compound reference action. Generic fragments remain unsupported/reviewable.
    for j, gen_node in enumerate(gen):
        if gen_node.id in mapped_gen or _is_generic(gen_node.label):
            continue
        choices: list[tuple[float, int]] = []
        for index, mapping in enumerate(mappings):
            if len(mapping.unit_ids) != 1 or len(mapping.generated_ids) != 1:
                continue
            reference_id = mapping.reference_ids[0]
            i = ref_index[reference_id]
            if (
                _compound(ref[i].label)
                and _adjacent(generated, gen_node.id, mapping.generated_ids[0])
                and pair_scores[i][j] >= threshold
                and _compound_component_compatible(
                    ref[i].label or "", gen_node.label or ""
                )
            ):
                choices.append((pair_scores[i][j], index))
        if not choices:
            continue
        score, mapping_index = max(choices)
        prior = mappings[mapping_index]
        generated_ids = tuple(sorted((*prior.generated_ids, gen_node.id)))
        group_id = "group:" + "+".join(generated_ids)
        mappings[mapping_index] = _mapping(
            case_id, candidate_id, [unit_by_ref[prior.reference_ids[0]]], generated_ids,
            group_id, "one_to_many", [*prior.similarities, score],
            {"basis": "compound_reference_and_adjacent_generated_context"},
        )
        mapped_gen.add(gen_node.id)

    # Actor omission is representation variation. An explicit conflicting actor
    # is reviewable when the source identifies essential responsibility; it does
    # not automatically turn a preserved activity into a false negative.
    for index, mapping in enumerate(tuple(mappings)):
        source_actors = {
            actor for reference_id in mapping.reference_ids
            for actor in (unit_by_ref[reference_id].actor or "").split()
        }
        generated_actors = {
            actor for generated_id in mapping.generated_ids
            for actor in (group_by_gen[generated_id].explicit_actor or "").split()
            if generated_id in group_by_gen
        }
        if source_actors and generated_actors and source_actors.isdisjoint(generated_actors):
            mappings[index] = replace(
                mapping,
                evidence={
                    **mapping.evidence,
                    "source_actors": sorted(source_actors),
                    "generated_actors": sorted(generated_actors),
                },
                review_triggers=tuple(sorted(set(mapping.review_triggers) | {
                    "semantically_essential_role_mismatch"
                })),
            )

    exposed_generated_groups = list(generated_groups)
    known_group_ids = {group.group_id for group in exposed_generated_groups}
    for mapping in mappings:
        if mapping.generated_group_id in known_group_ids:
            continue
        members = [group_by_gen[generated_id] for generated_id in mapping.generated_ids]
        actors = sorted({
            actor for member in members
            for actor in (member.explicit_actor or "").split()
        })
        exposed_generated_groups.append(GeneratedActivityGroup(
            mapping.generated_group_id,
            mapping.generated_ids,
            tuple(label for member in members for label in member.generated_labels),
            all(member.source_supported for member in members),
            str(mapping.evidence.get("source_passage", "")),
            min(member.source_grounding for member in members),
            min(member.lexical_grounding for member in members),
            " ".join(actors) if actors else None,
        ))
        known_group_ids.add(mapping.generated_group_id)

    preserved_core = {
        reference_id for mapping in mappings for reference_id in mapping.reference_ids
        if unit_by_ref[reference_id].importance == "core"
    }
    missing_core = tuple(
        unit.unit_id for unit in units
        if unit.importance == "core" and not (set(unit.reference_ids) & preserved_core)
    )
    unsupported = tuple(
        group.group_id for group in generated_groups
        if not group.source_supported and not (set(group.generated_ids) & mapped_gen)
    )
    detail_mismatches: list[Mapping[str, Any]] = []
    for unit in units:
        if unit.importance == "secondary" and not (set(unit.reference_ids) & mapped_ref):
            detail_mismatches.append({
                "kind": "reference_detail_not_preserved", "unit_id": unit.unit_id,
                "reference_labels": list(unit.reference_labels), "source_passage": unit.source_passage,
            })
    for group in generated_groups:
        if group.source_supported and not (set(group.generated_ids) & mapped_gen):
            detail_mismatches.append({
                "kind": "source_supported_generated_detail", "group_id": group.group_id,
                "generated_labels": list(group.generated_labels), "source_passage": group.source_passage,
            })

    variations = tuple(
        GranularityVariation(
            mapping.mapping_id,
            "merge" if mapping.kind == "many_to_one" else "split",
            mapping.unit_ids,
            mapping.generated_ids,
            "Semantic meaning is preserved with different action granularity.",
        )
        for mapping in mappings if mapping.kind in {"many_to_one", "one_to_many"}
    )
    ambiguous: list[Mapping[str, Any]] = []
    for unit in units:
        if (
            abs(unit.source_grounding - SOURCE_GROUNDING_THRESHOLD) <= 0.04
            and unit.lexical_grounding < 0.5
        ):
            ambiguous.append({
                "unit_id": unit.unit_id,
                "trigger": "unclear_process_text_interpretation",
                "source_grounding": unit.source_grounding,
                "source_passage": unit.source_passage,
            })
    for i, ref_node in enumerate(ref):
        if ref_node.id in mapped_ref or units[i].importance != "core":
            continue
        candidates = [
            {"generated_id": gen[j].id, "label": gen[j].label, "similarity": pair_scores[i][j]}
            for j in range(len(gen))
            if pair_scores[i][j] >= CONTEXTUAL_RESCUE_FLOOR
            and compatibility_veto(ref_node.label or "", gen[j].label or "").compatible
        ]
        if candidates:
            trigger = "vague_generic_multi_coverage" if any(
                _is_generic(candidate["label"]) for candidate in candidates
            ) else "ambiguous_semantic_mapping"
            ambiguous.append({
                "unit_id": units[i].unit_id, "trigger": trigger,
                "candidates": sorted(candidates, key=lambda item: (-item["similarity"], item["generated_id"])),
            })

    items: list[AutomaticItem] = []
    for mapping in mappings:
        core_units = [unit_by_ref[item] for item in mapping.reference_ids
                      if unit_by_ref[item].importance == "core"]
        if not core_units:
            continue
        items.append(AutomaticItem(
            case_id, candidate_id, "Action", mapping.mapping_id, "TP",
            {"semantic_unit_ids": list(mapping.unit_ids), "generated_ids": list(mapping.generated_ids),
             "mapping_kind": mapping.kind, "review_triggers": list(mapping.review_triggers)},
            dict(mapping.evidence),
            "Core source-grounded semantic activity is preserved.",
        ))
    for unit_id in missing_core:
        unit = next(item for item in units if item.unit_id == unit_id)
        items.append(AutomaticItem(
            case_id, candidate_id, "Action",
            evaluation_item_id(case_id, candidate_id, "semantic-action", "missing", unit_id), "FN",
            {"semantic_unit_id": unit_id, "review_triggers": []},
            {"reference_labels": list(unit.reference_labels), "source_passage": unit.source_passage,
             "source_grounding": unit.source_grounding},
            "Core source-grounded semantic activity is missing.",
        ))
    for group_id in unsupported:
        group = next(item for item in generated_groups if item.group_id == group_id)
        items.append(AutomaticItem(
            case_id, candidate_id, "Action",
            evaluation_item_id(case_id, candidate_id, "semantic-action", "unsupported", group_id), "FP",
            {"generated_group_id": group_id, "review_triggers": []},
            {"generated_labels": list(group.generated_labels), "source_grounding": group.source_grounding,
             "lexical_grounding": group.lexical_grounding},
            "Generated activity introduces meaning unsupported by the process text.",
        ))
    for variation in variations:
        items.append(AutomaticItem(
            case_id, candidate_id, "Action", variation.variation_id + ":gv", "GV",
            {"kind": variation.kind, "unit_ids": list(variation.unit_ids),
             "generated_ids": list(variation.generated_ids), "review_triggers": []},
            {}, variation.rationale,
        ))
    for index, item in enumerate(ambiguous):
        items.append(AutomaticItem(
            case_id, candidate_id, "Action",
            evaluation_item_id(case_id, candidate_id, "semantic-action", "ambiguous", str(index)),
            "AMBIGUOUS", {"review_triggers": [item["trigger"]], **item}, {},
            "A plausible mapping was not accepted automatically.",
        ))

    review_flags = tuple(sorted({
        trigger for mapping in mappings for trigger in mapping.review_triggers
    } | {str(item["trigger"]) for item in ambiguous}))
    counts = Counts(
        tp=len(preserved_core),
        fp=len(unsupported),
        fn=len(missing_core),
    )
    return SemanticActionResult(
        case_id, candidate_id, units, tuple(exposed_generated_groups), tuple(mappings), missing_core,
        unsupported, variations, tuple(ambiguous), tuple(detail_mismatches), review_flags,
        counts, tuple(items), legacy.matches,
    )
