"""Source-grounded Friedrich semantic evaluator."""

EVALUATOR_VERSION = "friedrich-semantic-action-v1.0.0"
EVALUATOR_SCHEMA = "friedrich-semantic-evaluator/v1"
ACTION_METHODOLOGY_VERSION = "source-grounded-semantic-activity-groups/v1"

