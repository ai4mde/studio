from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
import re
from typing import Any, Literal, Mapping, Sequence
import xml.etree.ElementTree as ET
import zipfile

from evaluation.friedrich_v3.core import (
    EvalGraph,
    evaluation_item_id,
    normalize_label,
    reachable,
    strongly_connected_components,
)

from .action import SemanticActionResult
from .flow import SemanticFlowResult


RegionType = Literal[
    "exclusive_optional",
    "convergence",
    "parallel_synchronization",
    "simple_loop",
    "loop_exit",
    "rework_loop",
    "interruption_restart",
]
RegionOutcome = Literal["full", "partial", "fail", "unscorable"]
CoverageStatus = Literal["sufficient", "limited", "insufficient", "not_applicable"]
StructureStatus = Literal[
    "supported",
    "partially_supported",
    "limited_evidence",
    "insufficient_evidence",
    "semantic_failure",
    "not_applicable",
]

_REWORK_CUES = re.compile(r"\b(rework|correct|correction|resolve|repair|re[- ]?prioriti[sz]e)\b")
_RESTART_CUES = re.compile(r"\b(restart|interrupt|cancel|new (?:physical|electrical) design)\b")


@dataclass(frozen=True, slots=True)
class ControlEvidence:
    evidence_id: str
    event_type: str
    label: str | None
    trigger_type: str | None
    interrupting: bool | None
    scope_id: str | None
    scope_label: str | None
    outgoing_target_id: str | None
    outgoing_target_label: str | None
    provenance: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class BehavioralRegion:
    region_id: str
    region_type: RegionType
    source_side: Literal["reference", "generated"]
    control_ids: tuple[str, ...]
    entry_unit_ids: tuple[str, ...]
    branch_unit_ids: tuple[tuple[str, ...], ...]
    branch_labels: tuple[str | None, ...]
    continuation_unit_ids: tuple[str, ...]
    body_unit_ids: tuple[str, ...]
    exit_unit_ids: tuple[str, ...]
    restart_target_unit_ids: tuple[str, ...]
    parent_region_id: str | None
    parent_branch_index: int | None
    anchor_complete: bool
    evidence: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class RegionAssessment:
    reference_region_id: str
    generated_region_id: str | None
    region_type: RegionType
    outcome: RegionOutcome
    findings: tuple[str, ...]
    critical_findings: tuple[str, ...]
    review_triggers: tuple[str, ...]
    evidence: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class UnsupportedGeneratedRegion:
    generated_region_id: str
    region_type: RegionType
    determination: Literal["unsupported", "ambiguous"]
    finding: str
    evidence: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class StructureItem:
    item_id: str
    label: str
    reference_region_id: str | None
    generated_region_id: str | None
    finding: str
    evidence: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class SemanticStructureResult:
    schema_version: str
    case_id: str
    candidate_id: str
    reference_regions: tuple[BehavioralRegion, ...]
    generated_regions: tuple[BehavioralRegion, ...]
    region_assessments: tuple[RegionAssessment, ...]
    unsupported_generated_regions: tuple[UnsupportedGeneratedRegion, ...]
    total_required_regions: int
    comparable_regions: int
    full_count: int
    partial_count: int
    fail_count: int
    unscorable_count: int
    full_rate: float | None
    partial_rate: float | None
    fail_rate: float | None
    unscorable_rate: float | None
    structure_coverage: float | None
    coverage_status: CoverageStatus
    structure_status: StructureStatus
    critical_findings: tuple[str, ...]
    human_review_required: bool
    review_flags: tuple[str, ...]
    upstream_context: Mapping[str, Any]
    items: tuple[StructureItem, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _reference_xml(path: Path) -> bytes:
    if path.suffix.casefold() == ".zip":
        with zipfile.ZipFile(path) as archive:
            return archive.read("workflow/workflow.xml")
    return path.read_bytes()


def _child_text(element: ET.Element, name: str) -> str | None:
    for child in element:
        if _local(child.tag) == name and child.text:
            return child.text.strip()
    return None


def _properties(element: ET.Element) -> dict[str, str]:
    result: dict[str, str] = {}
    for prop in element.iter():
        name = prop.get("name")
        if not name:
            continue
        value = prop.get("value")
        if value is None and prop.text:
            value = prop.text.strip()
        if value is not None:
            result[name] = value
    return result


def load_bpmn_control_evidence(path: str | Path) -> tuple[ControlEvidence, ...]:
    """Read only control semantics intentionally omitted from EvalGraph.

    Raw IDs are retained solely as provenance and graph-lookup keys. They are
    never compared as evidence of semantic correctness.
    """
    source = Path(path)
    root = ET.fromstring(_reference_xml(source))
    modules = [item for item in root.iter() if _local(item.tag) == "WorkflowModule"]
    names = {
        module_id: normalize_label(_child_text(module, "ModuleName"))
        for module in modules
        if (module_id := _child_text(module, "ModuleId"))
    }
    evidence: list[ControlEvidence] = []
    for module in modules:
        if module.get("moduleType") != "IntermediateEvent":
            continue
        event_id = _child_text(module, "ModuleId") or ""
        props = _properties(module)
        parent = next(
            (child.get("moduleId") for child in module if _local(child.tag) == "ParentModule"),
            None,
        )
        outgoing = next(
            (
                child.get("moduleOutId")
                for child in module
                if _local(child.tag) == "Connection"
                and child.get("type") == "SequenceFlow"
            ),
            None,
        )
        cancel = props.get("CancelActivity") or props.get("IsInterrupting")
        interrupting = None if cancel is None else cancel.casefold() == "true"
        evidence.append(ControlEvidence(
            evidence_id=f"bpmn-event:{event_id}",
            event_type="intermediate_event",
            label=names.get(event_id),
            trigger_type=normalize_label(props.get("TriggerType")),
            interrupting=interrupting,
            scope_id=parent,
            scope_label=names.get(parent or ""),
            outgoing_target_id=outgoing,
            outgoing_target_label=names.get(outgoing or ""),
            provenance={
                "adapter": "friedrich-bpmn-control-evidence/v1",
                "source_path": str(source),
                "element_kind": "IntermediateEvent",
                "element_id": event_id,
            },
        ))
    return tuple(sorted(evidence, key=lambda item: item.evidence_id))


def _distance(graph: EvalGraph, source: str, target: str) -> int | None:
    queue = deque([(source, 0)])
    seen = {source}
    while queue:
        current, distance = queue.popleft()
        if current == target:
            return distance
        for following in graph.outgoing[current]:
            if following not in seen:
                seen.add(following)
                queue.append((following, distance + 1))
    return None


def _nearest_common(graph: EvalGraph, starts: Sequence[str]) -> str | None:
    if len(starts) < 2:
        return None
    reachable_sets = [{start, *reachable(graph, start)} for start in starts]
    common = set.intersection(*reachable_sets)
    if not common:
        return None
    return min(
        common,
        key=lambda node_id: (
            max(_distance(graph, start, node_id) or 0 for start in starts),
            sum(_distance(graph, start, node_id) or 0 for start in starts),
            node_id,
        ),
    )


def _until(graph: EvalGraph, start: str, stop: str | None) -> set[str]:
    seen: set[str] = set()
    queue = deque([start])
    while queue:
        current = queue.popleft()
        if current == stop or current in seen:
            continue
        seen.add(current)
        queue.extend(graph.outgoing[current])
    return seen


def _nearest_units(
    graph: EvalGraph,
    starts: Sequence[str],
    node_to_units: Mapping[str, frozenset[str]],
    *,
    reverse: bool = False,
) -> tuple[str, ...]:
    adjacency = graph.incoming if reverse else graph.outgoing
    queue = deque((item, 0) for item in starts)
    seen: set[str] = set()
    found: set[str] = set()
    found_distance: int | None = None
    while queue:
        current, distance = queue.popleft()
        if current in seen or (found_distance is not None and distance > found_distance):
            continue
        seen.add(current)
        if current in node_to_units:
            found.update(node_to_units[current])
            found_distance = distance
            continue
        queue.extend((item, distance + 1) for item in adjacency[current])
    return tuple(sorted(found))


def _cyclic_components(graph: EvalGraph) -> tuple[frozenset[str], ...]:
    self_loops = {edge.source for edge in graph.edges if edge.source == edge.target}
    return tuple(
        component
        for component in strongly_connected_components(graph)
        if len(component) > 1 or bool(component & self_loops)
    )


def _edge_label(graph: EvalGraph, source: str, target: str) -> str | None:
    return next(
        (edge.label for edge in graph.edges if edge.source == source and edge.target == target),
        None,
    )


def _terminal_label(graph: EvalGraph, nodes: set[str]) -> str | None:
    labels = sorted(
        node.label for node_id in nodes
        if (node := graph.by_id[node_id]).type == "final" and node.label
    )
    return " / ".join(labels) if labels else None


def _extract_graph_regions(
    graph: EvalGraph,
    node_to_units: Mapping[str, frozenset[str]],
    side: Literal["reference", "generated"],
    source_text: str,
    comparable_units: frozenset[str] | None = None,
) -> list[BehavioralRegion]:
    regions: list[BehavioralRegion] = []
    cyclic = _cyclic_components(graph)
    cyclic_nodes = set().union(*cyclic) if cyclic else set()
    action_ids = {node.id for node in graph.nodes if node.type == "action"}

    for control in sorted(graph.nodes, key=lambda item: item.id):
        if control.type not in {"decision", "fork"} or control.id in cyclic_nodes:
            continue
        starts = graph.outgoing[control.id]
        if len(starts) < 2:
            continue
        continuation = _nearest_common(graph, starts)
        branch_units: list[tuple[str, ...]] = []
        branch_labels: list[str | None] = []
        raw_actions: set[str] = set()
        for start in starts:
            nodes = _until(graph, start, continuation)
            branch_raw = nodes & action_ids
            raw_actions.update(branch_raw)
            branch_units.append(tuple(sorted({
                unit for node_id in branch_raw for unit in node_to_units.get(node_id, ())
            })))
            label = _edge_label(graph, control.id, start)
            terminal = _terminal_label(graph, nodes)
            branch_labels.append(" / ".join(part for part in (label, terminal) if part) or None)
        raw_unit_ids = {
            unit for node_id in raw_actions for unit in node_to_units.get(node_id, ())
        }
        continuation_units = _nearest_units(
            graph, (continuation,) if continuation else (), node_to_units
        )
        closure = None
        if continuation:
            closure = (
                "synchronized"
                if control.type == "fork"
                and (
                    graph.by_id[continuation].type == "join"
                    or len(graph.incoming[continuation]) > 1
                )
                else "converged"
            )
        regions.append(BehavioralRegion(
            region_id=f"{side}:control:{control.id}",
            region_type=(
                "exclusive_optional" if control.type == "decision"
                else "parallel_synchronization"
            ),
            source_side=side,
            control_ids=(control.id,),
            entry_unit_ids=_nearest_units(graph, (control.id,), node_to_units, reverse=True),
            branch_unit_ids=tuple(branch_units),
            branch_labels=tuple(branch_labels),
            continuation_unit_ids=continuation_units,
            body_unit_ids=tuple(sorted({item for branch in branch_units for item in branch})),
            exit_unit_ids=continuation_units,
            restart_target_unit_ids=(),
            parent_region_id=None,
            parent_branch_index=None,
            anchor_complete=(
                len({node_id for node_id in raw_actions if node_id in node_to_units})
                == len(raw_actions)
                and (comparable_units is None or raw_unit_ids <= comparable_units)
            ),
            evidence={
                "control_type": control.type,
                "control_label": control.label,
                "continuation_node_type": graph.by_id[continuation].type if continuation else None,
                "closure": closure,
                "raw_action_count": len(raw_actions),
                "mapped_action_count": sum(node_id in node_to_units for node_id in raw_actions),
            },
        ))

    normalized_source = normalize_label(source_text) or ""
    for index, component in enumerate(sorted(cyclic, key=lambda item: sorted(item))):
        raw_body = component & action_ids
        if not raw_body:
            continue
        body_units = tuple(sorted({
            unit for node_id in raw_body for unit in node_to_units.get(node_id, ())
        }))
        outgoing = sorted({
            edge.target for edge in graph.edges
            if edge.source in component and edge.target not in component
        })
        exits = _nearest_units(graph, outgoing, node_to_units)
        component_labels = " ".join(
            graph.by_id[node_id].label or "" for node_id in sorted(component)
        )
        is_rework = bool(_REWORK_CUES.search(normalize_label(component_labels) or ""))
        if not is_rework and _REWORK_CUES.search(normalized_source):
            is_rework = any(
                (_edge_label(graph, edge.source, edge.target) or "") in {"retry", "no", "fail"}
                for edge in graph.edges if edge.source in component and edge.target in component
            )
        region_id = f"{side}:loop:{index}:" + ",".join(sorted(component))
        raw_unit_ids = {
            unit for node_id in raw_body for unit in node_to_units.get(node_id, ())
        }
        anchor_complete = (
            len({node_id for node_id in raw_body if node_id in node_to_units}) == len(raw_body)
            and (comparable_units is None or raw_unit_ids <= comparable_units)
        )
        regions.append(BehavioralRegion(
            region_id=region_id,
            region_type="rework_loop" if is_rework else "simple_loop",
            source_side=side,
            control_ids=tuple(sorted(component - raw_body)),
            entry_unit_ids=_nearest_units(graph, tuple(sorted(component)), node_to_units),
            branch_unit_ids=(),
            branch_labels=(),
            continuation_unit_ids=exits,
            body_unit_ids=body_units,
            exit_unit_ids=exits,
            restart_target_unit_ids=body_units[:1],
            parent_region_id=None,
            parent_branch_index=None,
            anchor_complete=anchor_complete,
            evidence={"component_nodes": sorted(component), "repetition": True},
        ))
        if outgoing:
            regions.append(BehavioralRegion(
                region_id=f"{region_id}:exit",
                region_type="loop_exit",
                source_side=side,
                control_ids=tuple(sorted(component - raw_body)),
                entry_unit_ids=body_units,
                branch_unit_ids=(),
                branch_labels=(),
                continuation_unit_ids=exits,
                body_unit_ids=body_units,
                exit_unit_ids=exits,
                restart_target_unit_ids=(),
                parent_region_id=region_id,
                parent_branch_index=None,
                anchor_complete=anchor_complete,
                evidence={"exit_boundary_count": len(outgoing)},
            ))
    return regions


def _units_for_reference(actions: SemanticActionResult) -> dict[str, frozenset[str]]:
    return {
        reference_id: frozenset({unit.unit_id})
        for unit in actions.semantic_activity_units
        for reference_id in unit.reference_ids
    }


def _units_for_generated(actions: SemanticActionResult) -> dict[str, frozenset[str]]:
    result: dict[str, set[str]] = {}
    for mapping in actions.accepted_mappings:
        for generated_id in mapping.generated_ids:
            result.setdefault(generated_id, set()).update(mapping.unit_ids)
    return {key: frozenset(value) for key, value in result.items()}


def _event_regions(
    evidence: Sequence[ControlEvidence],
    reference: EvalGraph,
    reference_units: Mapping[str, frozenset[str]],
    comparable_units: frozenset[str],
) -> list[BehavioralRegion]:
    result: list[BehavioralRegion] = []
    for item in evidence:
        # Only boundary/attached events carry interruption-and-restart meaning.
        # Ordinary timer/message events remain supporting evidence for their
        # owning graph region and must not be promoted to restart requirements.
        if (
            not item.interrupting
            or item.trigger_type != "signal"
            or item.scope_id is None
        ):
            continue
        target_units = _nearest_units(
            reference,
            (item.outgoing_target_id,) if item.outgoing_target_id in reference.by_id else (),
            reference_units,
        )
        result.append(BehavioralRegion(
            region_id=f"reference:interrupt:{item.evidence_id}",
            region_type="interruption_restart",
            source_side="reference",
            control_ids=(),
            entry_unit_ids=(),
            branch_unit_ids=(),
            branch_labels=(item.label,),
            continuation_unit_ids=target_units,
            body_unit_ids=(),
            exit_unit_ids=(),
            restart_target_unit_ids=target_units,
            parent_region_id=None,
            parent_branch_index=None,
            anchor_complete=bool(target_units) and set(target_units) <= comparable_units,
            evidence={
                "event_type": item.event_type,
                "event_label": item.label,
                "trigger_type": item.trigger_type,
                "interrupting": item.interrupting,
                "scope_label": item.scope_label,
                "outgoing_target_label": item.outgoing_target_label,
                "provenance": dict(item.provenance),
            },
        ))
    return result


def _supplement_event_loop_exits(
    regions: list[BehavioralRegion], evidence: Sequence[ControlEvidence]
) -> list[BehavioralRegion]:
    """Restore an explicit loop-exit requirement omitted with event nodes."""
    has_external_event = any(
        item.scope_id is None
        and item.label
        and item.trigger_type in {"message", "signal", "link throwing", "linkthrowing"}
        for item in evidence
    )
    if not has_external_event:
        return regions
    loop_ids_with_exit = {
        item.parent_region_id for item in regions if item.region_type == "loop_exit"
    }
    additions: list[BehavioralRegion] = []
    for loop in regions:
        if loop.region_type not in {"simple_loop", "rework_loop"}:
            continue
        if loop.region_id in loop_ids_with_exit:
            continue
        additions.append(BehavioralRegion(
            region_id=f"{loop.region_id}:event-exit",
            region_type="loop_exit",
            source_side=loop.source_side,
            control_ids=loop.control_ids,
            entry_unit_ids=loop.body_unit_ids,
            branch_unit_ids=(),
            branch_labels=tuple(
                item.label for item in evidence
                if item.scope_id is None and item.label
                and item.trigger_type in {"message", "signal", "link throwing", "linkthrowing"}
            ),
            continuation_unit_ids=(),
            body_unit_ids=loop.body_unit_ids,
            exit_unit_ids=(),
            restart_target_unit_ids=(),
            parent_region_id=loop.region_id,
            parent_branch_index=None,
            anchor_complete=loop.anchor_complete,
            evidence={"exit_basis": "structured_intermediate_event"},
        ))
    return [*regions, *additions]


def _assign_hierarchy(regions: list[BehavioralRegion]) -> list[BehavioralRegion]:
    # Nesting is represented semantically by footprint containment; exact BPMN
    # depth and control-node count are deliberately ignored.
    from dataclasses import replace

    result: list[BehavioralRegion] = []
    for region in regions:
        footprint = set(region.body_unit_ids)
        containers = [
            other for other in regions
            if other.region_id != region.region_id
            and footprint
            and footprint < set(other.body_unit_ids)
        ]
        if not containers:
            result.append(region)
            continue
        parent = min(containers, key=lambda item: (len(item.body_unit_ids), item.region_id))
        branch_index = next(
            (index for index, branch in enumerate(parent.branch_unit_ids) if footprint <= set(branch)),
            None,
        )
        result.append(replace(
            region, parent_region_id=parent.region_id, parent_branch_index=branch_index
        ))
    return result


def _region_units(region: BehavioralRegion) -> set[str]:
    return set(region.body_unit_ids) | set(region.entry_unit_ids) | set(region.continuation_unit_ids)


def _jaccard(left: set[str], right: set[str]) -> float:
    return len(left & right) / len(left | right) if left or right else 0.0


def _compatible_type(reference: RegionType, generated: RegionType) -> bool:
    if reference == generated:
        return True
    return {reference, generated} <= {"simple_loop", "rework_loop"}


def _best_region(
    reference: BehavioralRegion,
    generated: Sequence[BehavioralRegion],
    used: set[str],
) -> BehavioralRegion | None:
    candidates = [item for item in generated if item.region_id not in used]
    if reference.region_type in {"simple_loop", "rework_loop"}:
        candidates = [
            item for item in candidates
            if item.region_type in {"simple_loop", "rework_loop"}
        ]
    elif reference.region_type == "loop_exit":
        candidates = [item for item in candidates if item.region_type == "loop_exit"]
    elif reference.region_type in {"exclusive_optional", "parallel_synchronization"}:
        candidates = [
            item for item in candidates
            if item.region_type in {"exclusive_optional", "parallel_synchronization"}
        ]
    if not candidates:
        return None
    reference_units = _region_units(reference)
    ranked = sorted(
        candidates,
        key=lambda item: (
            _compatible_type(reference.region_type, item.region_type),
            _jaccard(reference_units, _region_units(item)),
            len(set(reference.entry_unit_ids) & set(item.entry_unit_ids)),
            -abs(len(reference.branch_unit_ids) - len(item.branch_unit_ids)),
            item.region_id,
        ),
        reverse=True,
    )
    best = ranked[0]
    overlap = _jaccard(reference_units, _region_units(best))
    if not _compatible_type(reference.region_type, best.region_type) and overlap == 0:
        return None
    if reference_units and overlap == 0:
        return None
    return best


def _partition_preserved(reference: BehavioralRegion, generated: BehavioralRegion) -> bool:
    generated_branches = [set(branch) for branch in generated.branch_unit_ids]
    for branch in reference.branch_unit_ids:
        required = set(branch)
        if required and not any(required <= candidate for candidate in generated_branches):
            return False
    for left_index, left in enumerate(reference.branch_unit_ids):
        for right in reference.branch_unit_ids[left_index + 1:]:
            for left_unit in left:
                for right_unit in right:
                    if any({left_unit, right_unit} <= candidate for candidate in generated_branches):
                        return False
    return True


def _labels_supported(reference: BehavioralRegion, generated: BehavioralRegion) -> bool:
    reference_tokens = {
        token for label in reference.branch_labels if label
        for token in (normalize_label(label) or "").split()
        if len(token) > 2
    }
    generated_tokens = {
        token for label in generated.branch_labels if label
        for token in (normalize_label(label) or "").split()
        if len(token) > 2
    }
    return not reference_tokens or bool(reference_tokens & generated_tokens)


def _assess_event_region(
    reference_region: BehavioralRegion,
    generated: EvalGraph,
    generated_units: Mapping[str, frozenset[str]],
) -> RegionAssessment:
    label = normalize_label(str(reference_region.evidence.get("event_label") or "")) or ""
    subject = {token for token in label.split() if token in {"physical", "electrical", "design"}}
    candidates = [
        node for node in generated.nodes
        if node.label
        and (
            _RESTART_CUES.search(normalize_label(node.label) or "")
            or subject & set((normalize_label(node.label) or "").split())
        )
    ]
    if not reference_region.anchor_complete:
        return RegionAssessment(
            reference_region.region_id, None, reference_region.region_type, "unscorable",
            ("restart_target_unresolved",), (), ("unclear_restart_target",),
            {"candidate_control_ids": [node.id for node in candidates]},
        )
    if not candidates:
        return RegionAssessment(
            reference_region.region_id, None, reference_region.region_type, "fail",
            ("restart_terminated",), ("restart_terminated",), (),
            {"reason": "no generated interruption/restart behavior"},
        )
    target_units = set(reference_region.restart_target_unit_ids)
    for node in candidates:
        descendants = reachable(generated, node.id)
        reached_units = {
            unit for node_id in descendants for unit in generated_units.get(node_id, ())
        }
        cyclic = node.id in descendants
        if target_units & reached_units and cyclic:
            return RegionAssessment(
                reference_region.region_id, f"generated:event:{node.id}",
                reference_region.region_type, "full", ("restart_preserved",), (), (),
                {"generated_node_id": node.id, "reached_target_units": sorted(target_units & reached_units)},
            )
    terminates = all(
        any(generated.by_id[node_id].type == "final" for node_id in reachable(generated, node.id))
        for node in candidates
    )
    finding = "restart_terminated" if terminates else "restart_target_wrong"
    return RegionAssessment(
        reference_region.region_id, f"generated:event:{candidates[0].id}",
        reference_region.region_type, "fail", (finding,), (finding,), (),
        {"candidate_control_ids": [node.id for node in candidates], "required_target_units": sorted(target_units)},
    )


def _assess_region(
    reference_region: BehavioralRegion,
    generated_region: BehavioralRegion | None,
) -> RegionAssessment:
    if not reference_region.anchor_complete:
        return RegionAssessment(
            reference_region.region_id,
            generated_region.region_id if generated_region else None,
            reference_region.region_type,
            "unscorable",
            ("semantic_anchors_incomplete",),
            (),
            ("high_impact_missing_semantic_anchors",),
            {"reference_anchor_complete": False},
        )
    if generated_region is None:
        finding = {
            "parallel_synchronization": "parallel_serialized",
            "simple_loop": "loop_body_cannot_repeat",
            "rework_loop": "rework_return_lost",
            "loop_exit": "loop_exit_wrong",
        }.get(reference_region.region_type, "required_control_behavior_missing")
        critical = (finding,) if finding in {
            "parallel_serialized", "loop_body_cannot_repeat",
            "rework_return_lost", "loop_exit_wrong"
        } else ()
        return RegionAssessment(
            reference_region.region_id, None, reference_region.region_type, "fail",
            (finding,), critical, (), {"reason": "no behaviorally aligned generated region"},
        )
    findings: list[str] = []
    critical: list[str] = []
    if reference_region.region_type == "exclusive_optional" and generated_region.region_type == "parallel_synchronization":
        findings.append("exclusive_changed_to_parallel")
        critical.append("exclusive_changed_to_parallel")
    elif reference_region.region_type == "parallel_synchronization" and generated_region.region_type != "parallel_synchronization":
        findings.append("parallel_serialized")
        critical.append("parallel_serialized")
    elif reference_region.region_type == "rework_loop" and generated_region.region_type != "rework_loop":
        findings.append("rework_return_lost")
        critical.append("rework_return_lost")
    if reference_region.branch_unit_ids and not _partition_preserved(reference_region, generated_region):
        findings.append("wrong_branch_membership")
    if (
        reference_region.region_type == "exclusive_optional"
        and len(generated_region.branch_unit_ids) < len(reference_region.branch_unit_ids)
        and not _labels_supported(reference_region, generated_region)
    ):
        findings.append("required_alternative_missing")
    reference_closure = reference_region.evidence.get("closure")
    generated_closure = generated_region.evidence.get("closure")
    if reference_closure == "synchronized" and generated_closure != "synchronized":
        findings.append("synchronization_lost")
        critical.append("synchronization_lost")
    if reference_region.region_type == "loop_exit":
        required = set(reference_region.exit_unit_ids)
        actual = set(generated_region.exit_unit_ids)
        if required and not required <= actual:
            findings.append("loop_exit_wrong")
            critical.append("loop_exit_wrong")
    if critical:
        outcome: RegionOutcome = "fail"
    elif findings:
        outcome = "partial"
    else:
        outcome = "full"
        findings.append("behavior_preserved")
    return RegionAssessment(
        reference_region.region_id, generated_region.region_id,
        reference_region.region_type, outcome, tuple(findings), tuple(sorted(set(critical))), (),
        {
            "reference_units": sorted(_region_units(reference_region)),
            "generated_units": sorted(_region_units(generated_region)),
            "reference_closure": reference_closure,
            "generated_closure": generated_closure,
        },
    )


def _strictly_sequential_reference(
    units: set[str], reference: EvalGraph, reference_units: Mapping[str, frozenset[str]]
) -> bool:
    nodes = [node_id for node_id, mapped in reference_units.items() if mapped & units]
    return len(nodes) >= 2 and all(
        right in reachable(reference, left) or left in reachable(reference, right)
        for index, left in enumerate(nodes) for right in nodes[index + 1:]
    )


def evaluate_semantic_structure(
    case_id: str,
    candidate_id: str,
    reference: EvalGraph,
    generated: EvalGraph,
    actions: SemanticActionResult,
    flow: SemanticFlowResult | None = None,
    *,
    source_text: str = "",
    reference_control_evidence: Sequence[ControlEvidence] = (),
    critical_region_ids: frozenset[str] = frozenset(),
) -> SemanticStructureResult:
    """Evaluate categorical control behavior without inheriting upstream scores."""
    if actions.case_id != case_id or actions.candidate_id != candidate_id:
        raise ValueError("Action result identity does not match Structure evaluation identity")
    if flow and (flow.case_id != case_id or flow.candidate_id != candidate_id):
        raise ValueError("Flow result identity does not match Structure evaluation identity")

    reference_units = _units_for_reference(actions)
    generated_units = _units_for_generated(actions)
    comparable_units = frozenset(
        unit_id for mapping in actions.accepted_mappings for unit_id in mapping.unit_ids
    )
    reference_regions = _extract_graph_regions(
        reference, reference_units, "reference", source_text, comparable_units
    )
    reference_regions = _supplement_event_loop_exits(
        reference_regions, reference_control_evidence
    )
    reference_regions.extend(_event_regions(
        reference_control_evidence, reference, reference_units, comparable_units
    ))
    generated_regions = _extract_graph_regions(generated, generated_units, "generated", source_text)
    reference_regions = _assign_hierarchy(reference_regions)
    generated_regions = _assign_hierarchy(generated_regions)

    assessments: list[RegionAssessment] = []
    used_generated: set[str] = set()
    for region in sorted(reference_regions, key=lambda item: item.region_id):
        if region.region_type == "interruption_restart":
            assessment = _assess_event_region(region, generated, generated_units)
        else:
            match = _best_region(region, generated_regions, used_generated)
            assessment = _assess_region(region, match)
            if match:
                used_generated.add(match.region_id)
        assessments.append(assessment)

    unsupported: list[UnsupportedGeneratedRegion] = []
    for region in sorted(generated_regions, key=lambda item: item.region_id):
        if region.region_id in used_generated:
            continue
        units = _region_units(region)
        deterministic = bool(units) and region.anchor_complete and _strictly_sequential_reference(
            units, reference, reference_units
        )
        unsupported.append(UnsupportedGeneratedRegion(
            region.region_id,
            region.region_type,
            "unsupported" if deterministic else "ambiguous",
            "unsupported_generated_control" if deterministic else "generated_control_counterpart_uncertain",
            {"semantic_unit_ids": sorted(units)},
        ))

    full = sum(item.outcome == "full" for item in assessments)
    partial = sum(item.outcome == "partial" for item in assessments)
    failed = sum(item.outcome == "fail" for item in assessments)
    unscorable = sum(item.outcome == "unscorable" for item in assessments)
    total = len(assessments)
    comparable = full + partial + failed
    critical_unscorable = any(
        item.reference_region_id in critical_region_ids and item.outcome == "unscorable"
        for item in assessments
    )
    comparable_ids = {
        item.reference_region_id for item in assessments if item.outcome != "unscorable"
    }
    all_critical_comparable = bool(critical_region_ids) and critical_region_ids <= comparable_ids
    if total == 0:
        coverage_status: CoverageStatus = "not_applicable"
    elif comparable == total or all_critical_comparable:
        coverage_status = "sufficient"
    elif comparable * 2 >= total and not critical_unscorable:
        coverage_status = "limited"
    else:
        coverage_status = "insufficient"

    critical_findings = tuple(sorted({
        finding for item in assessments for finding in item.critical_findings
    }))
    deterministic_unsupported = any(item.determination == "unsupported" for item in unsupported)
    review_flags = tuple(sorted({
        trigger for item in assessments for trigger in item.review_triggers
    } | {
        "ambiguous_unsupported_generated_region"
        for item in unsupported if item.determination == "ambiguous"
    }))
    if failed or critical_findings or deterministic_unsupported:
        structure_status: StructureStatus = "semantic_failure"
    elif total == 0:
        structure_status = "not_applicable"
    elif coverage_status == "insufficient":
        structure_status = "insufficient_evidence"
    elif partial:
        structure_status = "partially_supported"
    elif coverage_status == "limited":
        structure_status = "limited_evidence"
    else:
        structure_status = "supported"
    human_review = coverage_status == "insufficient" or bool(review_flags)

    items: list[StructureItem] = [
        StructureItem(
            evaluation_item_id(case_id, candidate_id, "semantic-structure", item.reference_region_id),
            item.outcome.upper(), item.reference_region_id, item.generated_region_id,
            ",".join(item.findings), dict(item.evidence),
        )
        for item in assessments
    ]
    items.extend(
        StructureItem(
            evaluation_item_id(case_id, candidate_id, "semantic-structure", item.generated_region_id),
            "UNSUPPORTED" if item.determination == "unsupported" else "REVIEW",
            None, item.generated_region_id, item.finding, dict(item.evidence),
        )
        for item in unsupported
    )
    upstream_context = {
        "action_review_flags": list(actions.review_flags),
        "action_missing_core_count": len(actions.missing_core_activities),
        "flow_status": flow.flow_status if flow else None,
        "flow_coverage_status": flow.coverage_status if flow else None,
        "flow_unscorable_count": len(flow.unscorable_relations) if flow else None,
        "flow_reversal_count": len(flow.reversed_constraints) if flow else None,
        "note": "diagnostic context only; no upstream score contributes to Structure",
    }
    return SemanticStructureResult(
        "friedrich-semantic-structure/v1", case_id, candidate_id,
        tuple(sorted(reference_regions, key=lambda item: item.region_id)),
        tuple(sorted(generated_regions, key=lambda item: item.region_id)),
        tuple(assessments), tuple(unsupported), total, comparable,
        full, partial, failed, unscorable,
        full / comparable if comparable else None,
        partial / comparable if comparable else None,
        failed / comparable if comparable else None,
        unscorable / total if total else None,
        comparable / total if total else None,
        coverage_status, structure_status, critical_findings, human_review,
        review_flags, upstream_context, tuple(items),
    )
