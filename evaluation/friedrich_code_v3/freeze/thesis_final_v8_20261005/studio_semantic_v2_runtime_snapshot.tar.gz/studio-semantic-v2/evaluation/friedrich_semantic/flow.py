from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Literal, Mapping, Sequence

from evaluation.friedrich_v3.core import (
    AutomaticItem,
    Counts,
    EvalGraph,
    evaluation_item_id,
    reachable,
    strongly_connected_components,
)
from evaluation.friedrich_v3.flow import _precedence, _transitive_reduction

from .action import SemanticActionResult


RelationType = Literal[
    "required_precedence", "unordered", "parallel_compatible", "mutually_exclusive"
]
RelationScope = Literal["global", "branch_local", "loop_local", "loop_recurrence"]
CoverageStatus = Literal["sufficient", "limited", "insufficient"]
FlowStatus = Literal[
    "supported", "limited_evidence", "insufficient_evidence", "semantic_error_detected"
]
UnitRelation = tuple[str, str]


@dataclass(frozen=True, slots=True)
class SemanticFlowConstraint:
    constraint_id: str
    source_unit_id: str
    target_unit_id: str
    relation_type: RelationType
    scope: RelationScope
    evidence: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class FlowFinding:
    constraint_id: str
    source_unit_id: str
    target_unit_id: str
    finding: str
    evidence: Mapping[str, Any]
    review_triggers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SemanticFlowResult:
    case_id: str
    candidate_id: str
    semantic_group_anchors: tuple[Mapping[str, Any], ...]
    reference_precedence_constraints: tuple[SemanticFlowConstraint, ...]
    generated_precedence_constraints: tuple[SemanticFlowConstraint, ...]
    preserved_constraints: tuple[FlowFinding, ...]
    missing_constraints: tuple[FlowFinding, ...]
    reversed_constraints: tuple[FlowFinding, ...]
    unsupported_sequentializations: tuple[FlowFinding, ...]
    representation_variations: tuple[FlowFinding, ...]
    branch_local_findings: tuple[FlowFinding, ...]
    loop_local_findings: tuple[FlowFinding, ...]
    unscorable_relations: tuple[FlowFinding, ...]
    confidence: float
    flow_f1: float
    precedence_coverage: float
    comparable_required_relations: int
    total_required_relations: int
    coverage_status: CoverageStatus
    flow_status: FlowStatus
    human_review_required: bool
    counts: Counts
    review_flags: tuple[str, ...]
    items: tuple[AutomaticItem, ...]

    @property
    def metric_defined(self) -> bool:
        return bool(self.counts.tp or self.counts.fp or self.counts.fn)

    @property
    def reversal_count(self) -> int:
        return len(self.reversed_constraints)

    @property
    def unsupported_sequentialization_count(self) -> int:
        return len(self.unsupported_sequentializations)

    @property
    def unscorable_count(self) -> int:
        return len(self.unscorable_relations)

    @property
    def review_flag_count(self) -> int:
        return len(self.review_flags)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class _LoopFacts:
    within_iteration: frozenset[UnitRelation]
    recurrence: frozenset[UnitRelation]
    unsafe_unit_sets: tuple[frozenset[str], ...]


def _reachable_with_edges(
    outgoing: Mapping[str, Sequence[str]], source: str
) -> set[str]:
    seen: set[str] = set()
    queue = deque([source])
    while queue:
        current = queue.popleft()
        for target in outgoing.get(current, ()):
            if target in seen:
                continue
            seen.add(target)
            queue.append(target)
    return seen


def _cyclic_components(graph: EvalGraph) -> tuple[frozenset[str], ...]:
    self_loops = {edge.source for edge in graph.edges if edge.source == edge.target}
    return tuple(
        component for component in strongly_connected_components(graph)
        if len(component) > 1 or bool(component & self_loops)
    )


def _loop_facts(graph: EvalGraph, node_to_unit: Mapping[str, str]) -> _LoopFacts:
    within: set[UnitRelation] = set()
    recurrence: set[UnitRelation] = set()
    unsafe: list[frozenset[str]] = []
    for component in _cyclic_components(graph):
        unit_ids = frozenset(
            node_to_unit[node_id] for node_id in component if node_id in node_to_unit
        )
        if not unit_ids:
            continue
        entries = sorted(
            node_id for node_id in component
            if any(source not in component for source in graph.incoming[node_id])
        )
        if len(entries) != 1:
            unsafe.append(unit_ids)
            continue
        entry = entries[0]
        outgoing = {
            node_id: tuple(
                target for target in graph.outgoing[node_id]
                if target in component and not (target == entry and node_id != entry)
            )
            for node_id in component
        }
        closure = {node_id: _reachable_with_edges(outgoing, node_id) for node_id in component}
        if any(
            left != right and left in closure[right] and right in closure[left]
            for left in component for right in component
        ):
            unsafe.append(unit_ids)
            continue
        action_nodes = sorted(node_id for node_id in component if node_id in node_to_unit)
        for left in action_nodes:
            for right in action_nodes:
                if left != right and right in closure[left]:
                    left_unit, right_unit = node_to_unit[left], node_to_unit[right]
                    if left_unit != right_unit:
                        within.add((left_unit, right_unit))
        if len(unit_ids) == 1:
            unit = next(iter(unit_ids))
            recurrence.add((unit, unit))
            continue
        starts = {
            node_to_unit[node_id] for node_id in action_nodes
            if not any(
                node_id in closure[other] for other in action_nodes if other != node_id
            )
        }
        ends = {
            node_to_unit[node_id] for node_id in action_nodes
            if not any(
                other in closure[node_id] for other in action_nodes if other != node_id
            )
        }
        recurrence.update((end, start) for end in ends for start in starts)
    return _LoopFacts(frozenset(within), frozenset(recurrence), tuple(unsafe))


def _distance(graph: EvalGraph, source: str, target: str) -> int | None:
    queue = deque([(source, 0)])
    seen = {source}
    while queue:
        node_id, distance = queue.popleft()
        if node_id == target:
            return distance
        for following in graph.outgoing[node_id]:
            if following not in seen:
                seen.add(following)
                queue.append((following, distance + 1))
    return None


def _nearest_common(graph: EvalGraph, starts: Sequence[str]) -> str | None:
    if len(starts) < 2:
        return None
    reachable_sets = [{start, *reachable(graph, start)} for start in starts]
    common = set.intersection(*reachable_sets)
    if not common:
        return None
    return min(
        common,
        key=lambda node_id: (
            max(_distance(graph, start, node_id) or 0 for start in starts),
            sum(_distance(graph, start, node_id) or 0 for start in starts),
            node_id,
        ),
    )


def _until(graph: EvalGraph, start: str, stop: str | None) -> set[str]:
    seen: set[str] = set()
    queue = deque([start])
    while queue:
        node_id = queue.popleft()
        if node_id == stop or node_id in seen:
            continue
        seen.add(node_id)
        queue.extend(graph.outgoing[node_id])
    return seen


def _branch_relations(
    graph: EvalGraph, node_to_unit: Mapping[str, str]
) -> tuple[dict[UnitRelation, RelationType], set[UnitRelation]]:
    cross_branch: dict[UnitRelation, RelationType] = {}
    same_branch: set[UnitRelation] = set()
    cyclic_nodes = set().union(*_cyclic_components(graph)) if _cyclic_components(graph) else set()
    for control in sorted(graph.nodes, key=lambda node: node.id):
        if control.type not in {"decision", "fork"} or control.id in cyclic_nodes:
            continue
        starts = graph.outgoing[control.id]
        if len(starts) < 2:
            continue
        continuation = _nearest_common(graph, starts)
        branches = [
            {
                node_to_unit[node_id] for node_id in _until(graph, start, continuation)
                if node_id in node_to_unit
            }
            for start in starts
        ]
        relation_type: RelationType = (
            "mutually_exclusive" if control.type == "decision" else "parallel_compatible"
        )
        for branch in branches:
            same_branch.update(
                (left, right) for left in branch for right in branch if left != right
            )
        for left_index, left_branch in enumerate(branches):
            for right_branch in branches[left_index + 1:]:
                for left in left_branch:
                    for right in right_branch:
                        if left != right:
                            cross_branch[tuple(sorted((left, right)))] = relation_type
    return cross_branch, same_branch


def _weak_components(graph: EvalGraph, node_to_unit: Mapping[str, str]) -> dict[str, int]:
    undirected: dict[str, set[str]] = {node.id: set() for node in graph.nodes}
    for edge in graph.edges:
        undirected[edge.source].add(edge.target)
        undirected[edge.target].add(edge.source)
    result: dict[str, int] = {}
    component_id = 0
    for node_id in sorted(undirected):
        if node_id in result:
            continue
        queue = deque([node_id])
        result[node_id] = component_id
        while queue:
            current = queue.popleft()
            for neighbor in undirected[current]:
                if neighbor not in result:
                    result[neighbor] = component_id
                    queue.append(neighbor)
        component_id += 1
    unit_components: dict[str, int] = {}
    for node_id, unit_id in node_to_unit.items():
        unit_components.setdefault(unit_id, result[node_id])
    return unit_components


def _has_control_boundary(graph: EvalGraph, sources: Sequence[str], targets: Sequence[str]) -> bool:
    controls = {
        node.id for node in graph.nodes if node.type in {"decision", "fork"}
    }
    return any(
        control in reachable(graph, source) and target in reachable(graph, control)
        for source in sources for target in targets for control in controls
    )


def _constraint(
    case_id: str,
    candidate_id: str,
    side: str,
    source: str,
    target: str,
    relation_type: RelationType,
    scope: RelationScope,
    evidence: Mapping[str, Any],
) -> SemanticFlowConstraint:
    return SemanticFlowConstraint(
        evaluation_item_id(
            case_id, candidate_id, "semantic-flow", side, relation_type, scope, source, target
        ),
        source,
        target,
        relation_type,
        scope,
        dict(evidence),
    )


def _guarantees_before(
    left: frozenset[str], right: frozenset[str], precedence: set[UnitRelation]
) -> bool:
    return bool(left and right) and all(
        (source, target) in precedence for source in left for target in right
    )


def _mapped_node_precedence(
    graph: EvalGraph, generated_to_units: Mapping[str, frozenset[str]]
) -> tuple[set[UnitRelation], _LoopFacts, set[UnitRelation]]:
    action_ids = set(generated_to_units)
    strict_nodes = _precedence(graph, action_ids)
    node_loops = _loop_facts(graph, {node_id: node_id for node_id in action_ids})
    node_precedence = set(strict_nodes) | set(node_loops.within_iteration)
    node_to_primary_unit = {
        node_id: sorted(unit_ids)[0] for node_id, unit_ids in generated_to_units.items()
        if unit_ids
    }
    loops = _loop_facts(graph, node_to_primary_unit)
    projected = {
        (left_unit, right_unit)
        for left_node, right_node in node_precedence
        for left_unit in generated_to_units[left_node]
        for right_unit in generated_to_units[right_node]
        if left_unit != right_unit
    }
    return projected, loops, node_precedence


def evaluate_semantic_flow(
    case_id: str,
    candidate_id: str,
    reference: EvalGraph,
    generated: EvalGraph,
    actions: SemanticActionResult,
    *,
    source_text: str | None = None,
    critical_relations: frozenset[UnitRelation] = frozenset(),
) -> SemanticFlowResult:
    """Compare semantic precedence over frozen Stage 1 activity groups."""
    del source_text  # Reserved as supporting evidence for explicit ambiguity adapters.
    if actions.case_id != case_id or actions.candidate_id != candidate_id:
        raise ValueError("Action result identity does not match Flow evaluation identity")

    unsupported_controls = [
        f"{side}:{node.id}:{node.semantic_type}"
        for side, graph in (("reference", reference), ("generated", generated))
        for node in graph.nodes if node.type == "unsupported_control"
    ]
    unit_by_id = {unit.unit_id: unit for unit in actions.semantic_activity_units}
    core_units = {unit.unit_id for unit in actions.semantic_activity_units if unit.importance == "core"}
    reference_to_unit = {
        reference_id: unit.unit_id
        for unit in actions.semantic_activity_units
        for reference_id in unit.reference_ids
        if unit.unit_id in core_units
    }
    unit_to_generated: dict[str, set[str]] = {unit_id: set() for unit_id in core_units}
    generated_to_units: dict[str, set[str]] = {}
    mapping_by_unit: dict[str, list[Any]] = {unit_id: [] for unit_id in core_units}
    anchors: list[Mapping[str, Any]] = []
    for mapping in actions.accepted_mappings:
        mapped_units = tuple(unit_id for unit_id in mapping.unit_ids if unit_id in core_units)
        if not mapped_units:
            continue
        anchors.append({
            "mapping_id": mapping.mapping_id,
            "unit_ids": list(mapped_units),
            "generated_group_id": mapping.generated_group_id,
            "generated_ids": list(mapping.generated_ids),
            "kind": mapping.kind,
            "confidence": mapping.confidence,
            "review_triggers": list(mapping.review_triggers),
        })
        for unit_id in mapped_units:
            unit_to_generated[unit_id].update(mapping.generated_ids)
            mapping_by_unit[unit_id].append(mapping)
        for generated_id in mapping.generated_ids:
            generated_to_units.setdefault(generated_id, set()).update(mapped_units)
    frozen_unit_to_generated = {
        unit_id: frozenset(generated_ids)
        for unit_id, generated_ids in unit_to_generated.items()
    }
    frozen_generated_to_units = {
        generated_id: frozenset(unit_ids)
        for generated_id, unit_ids in generated_to_units.items()
    }

    strict_reference_nodes = _precedence(reference, set(reference_to_unit))
    full_reference_precedence = {
        (reference_to_unit[left], reference_to_unit[right])
        for left, right in strict_reference_nodes
        if reference_to_unit[left] != reference_to_unit[right]
    }
    reference_loops = _loop_facts(reference, reference_to_unit)
    full_reference_precedence.update(reference_loops.within_iteration)
    reduced_reference = _transitive_reduction(set(full_reference_precedence))
    branch_relations, same_branch = _branch_relations(reference, reference_to_unit)
    branch_relations = {
        pair: relation_type
        for pair, relation_type in branch_relations.items()
        if pair not in full_reference_precedence
        and (pair[1], pair[0]) not in full_reference_precedence
    }
    unit_components = _weak_components(reference, reference_to_unit)

    reference_constraints: list[SemanticFlowConstraint] = []
    reference_by_relation: dict[UnitRelation, SemanticFlowConstraint] = {}
    for source, target in sorted(reduced_reference):
        scope: RelationScope
        if (source, target) in reference_loops.within_iteration:
            scope = "loop_local"
        elif (source, target) in same_branch:
            scope = "branch_local"
        else:
            scope = "global"
        item = _constraint(
            case_id, candidate_id, "reference", source, target,
            "required_precedence", scope,
            {"source_reference_ids": list(unit_by_id[source].reference_ids),
             "target_reference_ids": list(unit_by_id[target].reference_ids)},
        )
        reference_constraints.append(item)
        reference_by_relation[(source, target)] = item
    for source, target in sorted(reference_loops.recurrence):
        item = _constraint(
            case_id, candidate_id, "reference", source, target,
            "required_precedence", "loop_recurrence",
            {"meaning": "the loop permits another iteration"},
        )
        reference_constraints.append(item)
        reference_by_relation[(source, target)] = item
    for (source, target), relation_type in sorted(branch_relations.items()):
        reference_constraints.append(_constraint(
            case_id, candidate_id, "reference", source, target, relation_type,
            "branch_local", {"basis": "distinct branches of the same reference split"},
        ))
    unordered_pairs: set[UnitRelation] = set()
    for index, source in enumerate(sorted(core_units)):
        for target in sorted(core_units)[index + 1:]:
            pair = (source, target)
            if (
                (source, target) not in full_reference_precedence
                and (target, source) not in full_reference_precedence
                and pair not in branch_relations
                and unit_components.get(source) == unit_components.get(target)
            ):
                unordered_pairs.add(pair)
                reference_constraints.append(_constraint(
                    case_id, candidate_id, "reference", source, target, "unordered",
                    "global", {"basis": "same component with no required direction"},
                ))

    generated_precedence, generated_loops, generated_node_precedence = _mapped_node_precedence(
        generated, frozen_generated_to_units
    )
    reduced_generated = _transitive_reduction(set(generated_precedence))
    generated_constraints = tuple(
        _constraint(
            case_id, candidate_id, "generated", source, target,
            "required_precedence", "global", {"basis": "projected generated reachability"},
        )
        for source, target in sorted(reduced_generated)
    )

    preserved: list[FlowFinding] = []
    missing: list[FlowFinding] = []
    reversed_items: list[FlowFinding] = []
    variations: list[FlowFinding] = []
    unscorable: list[FlowFinding] = []
    confidence_values: list[float] = []

    for constraint in reference_constraints:
        if constraint.relation_type != "required_precedence":
            continue
        source, target = constraint.source_unit_id, constraint.target_unit_id
        left, right = frozen_unit_to_generated.get(source, frozenset()), frozen_unit_to_generated.get(target, frozenset())
        mapping_confidence = min(
            [mapping.confidence for unit_id in {source, target} for mapping in mapping_by_unit.get(unit_id, ())],
            default=0.0,
        )
        triggers: set[str] = set()
        if 0.0 < mapping_confidence < 0.44:
            triggers.add("medium_confidence_action_grouping")
        if unsupported_controls:
            triggers.add("unsupported_control_affects_precedence")
            unscorable.append(FlowFinding(
                constraint.constraint_id, source, target, "unscorable",
                {"unsupported_controls": unsupported_controls}, tuple(sorted(triggers)),
            ))
            continue
        if not left or not right:
            triggers.add("unresolved_semantic_group_anchor")
            unscorable.append(FlowFinding(
                constraint.constraint_id, source, target, "unscorable_anchor",
                {"source_generated_ids": sorted(left), "target_generated_ids": sorted(right),
                 "reason": "required activity has no accepted semantic-group anchor"},
                tuple(sorted(triggers)),
            ))
            continue
        confidence_values.append(mapping_confidence)
        if constraint.scope == "loop_recurrence":
            if source == target:
                recurrence_preserved = any(
                    node_id in reachable(generated, node_id) for node_id in left
                )
            else:
                recurrence_preserved = all(
                    target_node in reachable(generated, source_node)
                    and source_node in reachable(generated, target_node)
                    for source_node in left for target_node in right
                )
            if recurrence_preserved:
                finding = FlowFinding(
                    constraint.constraint_id, source, target, "preserved_loop_recurrence",
                    {"source_generated_ids": sorted(left), "target_generated_ids": sorted(right)},
                    tuple(sorted(triggers)),
                )
                preserved.append(finding)
            else:
                missing.append(FlowFinding(
                    constraint.constraint_id, source, target, "missing_loop_recurrence",
                    {"source_generated_ids": sorted(left), "target_generated_ids": sorted(right)},
                    tuple(sorted(triggers)),
                ))
            continue
        if left & right:
            source_refs = unit_by_id[source].reference_ids
            target_refs = unit_by_id[target].reference_ids
            boundary = (
                constraint.scope in {"loop_local", "loop_recurrence"}
                or _has_control_boundary(reference, source_refs, target_refs)
                or (
                    unit_by_id[source].actor and unit_by_id[target].actor
                    and unit_by_id[source].actor != unit_by_id[target].actor
                )
            )
            if boundary:
                triggers.add("many_to_one_hides_ordering_boundary")
                missing.append(FlowFinding(
                    constraint.constraint_id, source, target, "missing_precedence",
                    {"shared_generated_ids": sorted(left & right), "boundary_hidden": True},
                    tuple(sorted(triggers)),
                ))
            else:
                variations.append(FlowFinding(
                    constraint.constraint_id, source, target, "granularity_collapsed_precedence",
                    {"shared_generated_ids": sorted(left & right)}, (),
                ))
            continue
        if _guarantees_before(left, right, generated_node_precedence):
            preserved.append(FlowFinding(
                constraint.constraint_id, source, target, "preserved_precedence",
                {"source_generated_ids": sorted(left), "target_generated_ids": sorted(right)},
                tuple(sorted(triggers)),
            ))
        elif _guarantees_before(right, left, generated_node_precedence):
            reversal = FlowFinding(
                constraint.constraint_id, source, target, "prohibited_reversal",
                {"generated_direction": [target, source]}, tuple(sorted(triggers)),
            )
            missing.append(FlowFinding(
                constraint.constraint_id, source, target, "missing_precedence",
                {"reason": "generated model guarantees the opposite direction"},
                tuple(sorted(triggers)),
            ))
            reversed_items.append(reversal)
        else:
            unsafe_loop = any(
                {source, target} <= unit_set for unit_set in generated_loops.unsafe_unit_sets
            )
            if unsafe_loop:
                triggers.add("loop_internal_order_unresolved")
                unscorable.append(FlowFinding(
                    constraint.constraint_id, source, target, "unscorable_loop_order",
                    {"reason": "generated loop has no unique safe within-iteration order"},
                    tuple(sorted(triggers)),
                ))
            else:
                missing.append(FlowFinding(
                    constraint.constraint_id, source, target, "missing_precedence",
                    {"source_generated_ids": sorted(left), "target_generated_ids": sorted(right)},
                    tuple(sorted(triggers)),
                ))

    unsupported_sequence: list[FlowFinding] = []
    unordered_lookup = unordered_pairs | set(branch_relations)
    for source, target in sorted(reduced_generated):
        if (source, target) in full_reference_precedence:
            continue
        if (target, source) in full_reference_precedence:
            continue  # Reversal is already one FN and a dedicated diagnostic.
        unordered_pair = tuple(sorted((source, target)))
        if unordered_pair not in unordered_lookup:
            continue
        reference_type = branch_relations.get(unordered_pair, "unordered")
        finding = FlowFinding(
            evaluation_item_id(case_id, candidate_id, "semantic-flow", "unsupported-sequence", source, target),
            source, target, "unsupported_sequentialization",
            {"generated_direction": [source, target], "reference_relation_type": reference_type}, (),
        )
        unsupported_sequence.append(finding)

    for unit_set in reference_loops.unsafe_unit_sets:
        unscorable.append(FlowFinding(
            evaluation_item_id(case_id, candidate_id, "semantic-flow", "unsafe-reference-loop", *sorted(unit_set)),
            min(unit_set), max(unit_set), "unscorable_loop_order",
            {"unit_ids": sorted(unit_set), "reason": "reference loop has no unique entry/order"},
            ("loop_internal_order_unresolved",),
        ))

    branch_findings = tuple(
        item for item in (*preserved, *missing, *unsupported_sequence)
        if (
            reference_by_relation.get((item.source_unit_id, item.target_unit_id), None)
            and reference_by_relation[(item.source_unit_id, item.target_unit_id)].scope
            == "branch_local"
        )
        or tuple(sorted((item.source_unit_id, item.target_unit_id))) in branch_relations
    )
    loop_findings = tuple(
        item for item in (*preserved, *missing, *variations, *unscorable)
        if reference_by_relation.get((item.source_unit_id, item.target_unit_id), None)
        and reference_by_relation[(item.source_unit_id, item.target_unit_id)].scope in {"loop_local", "loop_recurrence"}
    )
    required_count = sum(
        constraint.relation_type == "required_precedence" for constraint in reference_constraints
    )
    scored_required = len(preserved) + len(missing) + len(variations)
    coverage = scored_required / required_count if required_count else 1.0
    counts = Counts(
        tp=len(preserved) + len(variations),
        fp=len(unsupported_sequence),
        fn=len(missing),
    )
    all_findings = (
        *preserved, *missing, *reversed_items, *unsupported_sequence, *variations, *unscorable
    )
    review_flags = tuple(sorted({
        trigger for finding in all_findings for trigger in finding.review_triggers
    }))
    comparable_relations = {
        (finding.source_unit_id, finding.target_unit_id)
        for finding in (*preserved, *missing, *variations)
    }
    critical_unscorable = any(
        (finding.source_unit_id, finding.target_unit_id) in critical_relations
        for finding in unscorable
    )
    all_critical_comparable = (
        bool(critical_relations) and critical_relations <= comparable_relations
    )
    if scored_required == required_count or all_critical_comparable:
        coverage_status: CoverageStatus = "sufficient"
    elif scored_required * 2 >= required_count and not critical_unscorable:
        coverage_status = "limited"
    else:
        coverage_status = "insufficient"
    if counts.fp or counts.fn:
        flow_status: FlowStatus = "semantic_error_detected"
    elif coverage_status == "sufficient":
        flow_status = "supported"
    elif coverage_status == "limited":
        flow_status = "limited_evidence"
    else:
        flow_status = "insufficient_evidence"
    human_review_required = coverage_status == "insufficient" or bool(review_flags)
    items: list[AutomaticItem] = []
    for label, findings, rationale in (
        ("TP", preserved, "Required semantic precedence is preserved."),
        ("FN", missing, "Required semantic precedence is not preserved."),
        ("FP", unsupported_sequence, "Generated model imposes unsupported semantic ordering."),
        ("RV", variations, "Ordering difference is accepted as representation variation."),
        ("UNSCORABLE", unscorable, "Only this affected semantic relation is unscorable."),
    ):
        for finding in findings:
            items.append(AutomaticItem(
                case_id, candidate_id, "Flow", finding.constraint_id, label,
                {"source_unit_id": finding.source_unit_id,
                 "target_unit_id": finding.target_unit_id,
                 "finding": finding.finding,
                 "review_triggers": list(finding.review_triggers)},
                dict(finding.evidence), rationale,
            ))
    return SemanticFlowResult(
        case_id,
        candidate_id,
        tuple(sorted(anchors, key=lambda item: str(item["mapping_id"]))),
        tuple(sorted(reference_constraints, key=lambda item: item.constraint_id)),
        generated_constraints,
        tuple(preserved),
        tuple(missing),
        tuple(reversed_items),
        tuple(unsupported_sequence),
        tuple(variations),
        branch_findings,
        loop_findings,
        tuple(unscorable),
        sum(confidence_values) / len(confidence_values) if confidence_values else 0.0,
        counts.f1,
        coverage,
        scored_required,
        required_count,
        coverage_status,
        flow_status,
        human_review_required,
        counts,
        review_flags,
        tuple(items),
    )
